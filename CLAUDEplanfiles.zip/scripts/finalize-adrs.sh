#!/usr/bin/env bash
# ------------------------------------------------------------------------------
# finalize-adrs.sh — assign next ADR numbers and fill cross-references.
# Run from the repo root (where docs/adr or docs/adrs lives), AFTER copying the
# three new ADRs into that folder.
#
#   ./scripts/finalize-adrs.sh            # dry-run: show what it would do
#   ./scripts/finalize-adrs.sh --apply    # rename files + rewrite ADR IDs/refs
#
# It:
#   1. finds the ADR directory and the highest existing ADR number,
#   2. assigns the next sequential numbers to the three new ADRs (in a fixed order),
#   3. renames each file to include its number and replaces the "ADR-NNN" placeholder,
#   4. fills the Registry/Parcel ADR cross-reference by detecting it in the folder
#      (ADR-004 for authorisation is already referenced explicitly).
# ------------------------------------------------------------------------------
set -euo pipefail
APPLY="no"; [ "${1:-}" = "--apply" ] && APPLY="yes"

# 1. locate ADR dir
ADR_DIR=""
for d in docs/adr docs/adrs docs/architecture/decisions adr adrs; do
  [ -d "$d" ] && ADR_DIR="$d" && break
done
[ -n "$ADR_DIR" ] || { echo "ERROR: no ADR directory found (looked for docs/adr, docs/adrs, ...)."; exit 1; }
echo "ADR directory: $ADR_DIR"

# 2. highest existing ADR number (matches ADR-004, adr-0004, 0004-..., ADR_4_...)
highest=0
while IFS= read -r f; do
  base="$(basename "$f")"
  n="$(printf '%s' "$base" | grep -oiE 'adr[-_ ]*0*[0-9]+|^0*[0-9]+[-_]' | grep -oE '[0-9]+' | head -1 || true)"
  [ -n "${n:-}" ] && [ "$n" -gt "$highest" ] 2>/dev/null && highest="$n"
done < <(find "$ADR_DIR" -maxdepth 1 -type f -name '*.md')
echo "Highest existing ADR number: $highest"

# 3. the three new ADRs, in adoption order
NEW=(
  "ADR-registry-ownership-status-history.md"
  "ADR-delivery-platform-decisions.md"
  "ADR-pilot-nonfunctional-targets.md"
)

# 4. detect the Registry/Parcel ADR for cross-reference (by filename; exclude the 3 new ADRs)
REG_REF="$(find "$ADR_DIR" -maxdepth 1 -type f -name '*.md' \
  | grep -iE 'parcel|registry' \
  | grep -viE 'ownership-status-history|delivery-platform|pilot-nonfunctional' \
  | sort | head -1 || true)"
if [ -n "$REG_REF" ]; then
  REG_NUM="$(basename "$REG_REF" | grep -oiE 'adr[-_ ]*0*[0-9]+|^0*[0-9]+[-_]' | grep -oE '[0-9]+' | head -1 || true)"
  REG_LABEL="ADR-$(printf '%03d' "${REG_NUM:-0}") ($(basename "$REG_REF"))"
else
  REG_LABEL="ADR-<Registry/Parcel> (not found — fill manually)"
fi
echo "Registry/Parcel ADR reference: $REG_LABEL"
echo

next=$((highest+1))
for f in "${NEW[@]}"; do
  src="$ADR_DIR/$f"
  [ -f "$src" ] || { echo "SKIP (not found in $ADR_DIR): $f"; continue; }
  num="$(printf '%03d' "$next")"
  dest="$ADR_DIR/ADR-${num}-${f#ADR-}"
  echo "  ADR-$num  <-  $f   ->  $(basename "$dest")"
  if [ "$APPLY" = "yes" ]; then
    sed -i "s/ADR-NNN/ADR-${num}/g" "$src"
    # fill Registry/Parcel placeholder references
    sed -i "s#ADR-<Registry>#${REG_LABEL}#g; s#ADR-<Registry/Parcel>#${REG_LABEL}#g; s#ADR-<Registry ADR>#${REG_LABEL}#g" "$src"
    git mv "$src" "$dest" 2>/dev/null || mv "$src" "$dest"
  fi
  next=$((next+1))
done

echo
if [ "$APPLY" = "yes" ]; then
  echo "Applied. Review with 'git diff --staged' / 'git status', then commit (one ADR set)."
else
  echo "Dry-run only. Re-run with --apply to rename files and rewrite IDs/references."
fi
