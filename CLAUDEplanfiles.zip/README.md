# CLAUDE-plan — LandVault Governance & Development Plan

This repository holds the **governing blueprint and execution plan** for LandVault, read by
Claude Code (and any `AGENTS.md`-aware agent) to plan and build the platform. It is the
"what and why"; the application code lives in the separate **Development-Plan** repository.

## Contents

- `CLAUDE.md` / `AGENTS.md` — agent entry points (auto-loaded); import the blueprint below.
- `docs/bible/` — the full library: **LV-000 Constitution (v1.7)** through **LV-016**, plus the
  build-time rules (`LandVault-CLAUDE.md`). No lower document may contradict a higher one.
- `docs/adr/` — Architecture Decision Records: Registry ownership/status history; delivery-platform
  (StoragePort / R2 / WORM, Keycloak, Paystack); pilot non-functional targets.
- `docs/DEVELOPMENT_PLAN.md` — the approved MVP / pilot execution plan (phases, gates, first PRs).
- `.claude/` — `/plan` and `/review` commands, `planner` / `reviewer` subagents, test permissions.
- `.github/workflows/` — CI (frontend + backend) to copy into the code repo.
- `scripts/finalize-adrs.sh` — assigns ADR numbers when these ADRs are merged into the code repo.

## Using it

Point Claude Code at the **code repo** (`Development-Plan`) with this repo's `CLAUDE.md`,
`AGENTS.md`, and `docs/` present (copy them in, or keep this repo alongside and reference it).
Then: `Shift+Tab` for plan mode, `/plan <context>`, `/review <context>`. The plan's first step is
to re-observe the backend test suite green, then implement the ownership/status-history ADR
(Phase 1) before B4 Spatial.

## Note on the ADRs

The ADRs here **govern the code** and reference the code repo's ADR sequence (ADR-004 authorisation,
the Registry/Parcel ADR). When you bring them into `Development-Plan`, run `scripts/finalize-adrs.sh`
there to assign their real numbers and fill the cross-references.

## Prime directive

LandVault **preserves and verifies** land evidence. **It does not decide who owns land.** No code,
schema, API, or UI may assert title or ownership adjudication.

*Governed by LV-000 v1.7. Authored with Claude.*
