# AGENTS.md — LandVault (agent-agnostic instructions)

This file is the cross-agent entry point for the LandVault codebase. It is written to the
`AGENTS.md` convention, which many coding agents read automatically (Claude Code also reads it
via the import in `CLAUDE.md`). It tells any agent how to plan, build, test, and review here, and
points to the governing blueprint. **No lower-level document may contradict a higher one:**

`LV-000 Constitution → Bible (docs/bible/LV-001…LV-016) → ADRs → this file / CLAUDE.md → code`

## What LandVault is (one line)

A trusted digital infrastructure for land verification. It **preserves, verifies and governs**
land evidence; it does **not** determine ownership or title. Never write code or copy that claims
otherwise.

## Repository map

- `backend/`  — Python / FastAPI, organised by bounded context. Tests: **pytest**.
- `frontend/` — Next.js / TypeScript (four portals). Tests: **npm test**.
- `infra/`    — Terraform / Docker.
- `docs/bible/` — the full governing library (start with `LandVault-CLAUDE.md`, `LV-005` PRD, `LV-006` TRD, `LV-007` Security).

## Commands

| Purpose | Command |
|---|---|
| Frontend tests | `cd frontend && npm test` |
| Frontend typecheck | `cd frontend && npm run typecheck` |
| Backend tests | `cd backend && pytest` |
| List frontend tests | `cd frontend && npm test -- --listTests` |
| Collect backend tests | `cd backend && pytest --collect-only -q` |

## The non-negotiable rules (gating — never waive)

Each exists because a real, confirmed exploit made it necessary. Full detail: `docs/bible/LandVault-CLAUDE.md`.

1. New entity/table ships with its RLS/authorisation policy **in the same change**.
2. Secure-by-default: missing security config **halts startup**; no permissive defaults, no fallback secrets.
3. One authorisation path (single PDP/PEP). No parallel/bypass auth.
4. Scoring/validation **fails safe**: zero/missing data → low or `INSUFFICIENT_DATA`, never a passing score.
5. **Observe, then complete**: nothing is "done" until its tests have actually run and passed.
6. New dependencies: justified + version-pinned. Migrations: reversible + shipped with matching authz.
7. One bounded context per change; commit message explains *why*.
8. Platform, not aggregate: contexts own their data and integrate **by contract/events**, never by shared tables or a "God object". No transaction spans contexts.

## Workflow every agent should follow

1. **Plan first (read-only).** For any non-trivial task, produce a scoped, step-by-step plan for one
   bounded context before editing. State which tests must pass.
2. **Build** against the plan, obeying the rules above.
3. **Verify by observation.** Run `npm test` / `pytest`; a feature is complete only when they pass.
4. **Stop and ask a human** for: schema changes, new dependencies, auth/payments, data deletion,
   legal-adjacent logic (ownership/title/inheritance), irreversible production actions, or opening
   any post-MVP scope (Knowledge Graph, full Trust Engine scoring, Inheritance & Customary Law,
   marketplace escrow/ratings/disputes).

## Second-opinion review

To sanity-check a change or a plan, review it **against `docs/bible/`**: does it contradict the
Constitution or a Bible volume? does it break a non-negotiable rule? does it present planned work as
done? are the cited tests real and passing? Report findings ranked by severity; do not rubber-stamp.

If any instruction conflicts with a document in `docs/bible/`, the higher document prevails.
