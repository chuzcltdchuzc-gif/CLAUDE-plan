---
description: Scoped, read-only execution plan for one bounded context
argument-hint: <bounded-context, e.g. Registry>
---
Produce a step-by-step **execution plan** for the bounded context "$ARGUMENTS".
Do NOT edit any files — this is planning only.

The plan must:
- Obey every non-negotiable rule in `docs/bible/LandVault-CLAUDE.md` (they are gating).
- Satisfy the tiered Definition of Done, including: authorisation/RLS shipped in the same change
  as any new entity; no permissive security defaults; scoring fails safe on missing data;
  nothing complete without an observed passing test.
- Be scoped to a single bounded context and note where it integrates with others by contract.
- List the exact tests that must pass, and the commands to run them.
- Flag any step that needs human sign-off (schema, dependencies, auth/payments, deletion,
  legal-adjacent logic, irreversible actions, or post-MVP scope).

Context to load:
- Build rules:      @docs/bible/LandVault-CLAUDE.md
- Requirements:     @docs/bible/LV-005-Product-Requirements-PRD.md
- Architecture:     @docs/bible/LV-006-Technical-Requirements-TRD.md
- Existing frontend tests: !`cd frontend && npm test -- --listTests 2>/dev/null || echo "(no npm tests found)"`
- Existing backend tests:  !`cd backend && pytest --collect-only -q 2>/dev/null | head -50 || echo "(no pytest found)"`
- Frontend scripts: @frontend/package.json
