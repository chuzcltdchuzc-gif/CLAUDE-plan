---
description: Adversarial second-opinion review of a change or plan against the blueprint
argument-hint: <context, file, or "uncommitted diff">
---
Act as an independent, adversarial reviewer. Examine "$ARGUMENTS" and give a **second opinion** —
do NOT rubber-stamp, and do NOT edit files.

Check against the governing blueprint:
- Does it contradict `docs/bible/LV-000` (the Constitution) or any Bible volume? (Higher document wins.)
- Does it break any non-negotiable rule in `docs/bible/LandVault-CLAUDE.md`? (entity without RLS;
  permissive default; parallel auth path; scoring that passes on missing data; "done" without an
  observed passing test; cross-context transaction / shared tables.)
- Does it present planned/post-MVP capability as delivered? (candour)
- Are the cited tests real, and do they actually pass? Verify with the commands below.
- Does it claim an authority LandVault does not have, or let a commercial concern bias a trust
  function? (Articles XV.1 / XV.2)

Load and run:
- Rules & requirements: @docs/bible/LandVault-CLAUDE.md @docs/bible/LV-005-Product-Requirements-PRD.md
- Uncommitted changes: !`git diff --stat 2>/dev/null; git diff 2>/dev/null | head -400`
- Frontend tests: !`cd frontend && npm test 2>&1 | tail -30 || echo "(no npm tests / failed)"`
- Backend tests: !`cd backend && pytest -q 2>&1 | tail -30 || echo "(no pytest / failed)"`

Return findings ranked by severity (CRITICAL / MAJOR / MINOR), each with file+location, the problem,
and a concrete fix. End with a one-line verdict: safe to proceed, or not.
