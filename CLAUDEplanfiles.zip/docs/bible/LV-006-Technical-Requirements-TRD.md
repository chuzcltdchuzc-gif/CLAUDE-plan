# The Official LandVault Bible™

## Volume LV-006 — Technical Requirements Document (TRD)

*A subordinate volume of The Official LandVault Bible™, governed by LV-000 — The LandVault Constitution, and by LV-005 — the PRD.*

---

## Document Control

| Field | Entry |
|---|---|
| **Document ID** | LV-006 |
| **Title** | Technical Requirements Document (TRD) |
| **Library** | The Official LandVault Bible™ |
| **Tier** | Bible (subordinate to the Constitution; elaborated by ADRs) |
| **Version** | v0.1 (Draft for Review) |
| **Status** | Draft — Under Authorship |
| **Classification** | Public (Governance) |
| **Owner** | Office of the LandVault Constitution (Governance Authority) |
| **Governed By** | LV-000 (v1.7); LV-005 (PRD); consistent with LV-002, LV-003 |
| **Governs** | Implementation specifications; superseded in specifics only by ratified ADRs |
| **Source Baselines** | Development-Plan repository — stack (Python/FastAPI, Next.js/TypeScript, PostgreSQL+PostGIS, Keycloak/Auth0, Paystack, S3-compatible storage, Docker/Terraform), 13 bounded contexts, Engineering Rules, DoD, Phase Gates |
| **Review Cycle** | Per milestone, or upon a governing ADR |
| **Language** | English (UK) |

*Subordinate to LV-000 and LV-005. This document specifies architecture at the level of
requirements; specific decisions are recorded in Architecture Decision Records, which
elaborate — and may, through governed amendment, supersede specific provisions of — this
document without ever contradicting the Constitution. Where a technology is named, it
reflects the current frozen baselines; substitutions proceed by ADR with pinned versions.*

---

## 1. Purpose and Scope

Where the PRD (LV-005) specifies **what** the product must do, this document specifies
**how** it is built, at the level of architecture and technical requirements. It defines
the architectural model, the technology baseline, the structure and boundaries of each
context, the integration mechanisms, the authorisation and data-integrity architecture, the
non-functional architecture, and the deployment model. It is written so that implementation
specifications and code can be derived from it and tested against it, and so that every
technical requirement is answerable to a product requirement and, above it, to the
Constitution.

## 2. Architectural Model

LandVault is built as a **platform of independent bounded contexts**, in accordance with
Article X. It is not a single application over one database, and no component is a central
object through which all others pass. Each context owns its own model, its own data, and the
invariants within its boundary, and exposes its capabilities to other contexts only through
explicit, versioned contracts — published events and defined interfaces. A context refers to
another context's concepts by identity (for example, a parcel identifier) and never by
embedding or reaching into another context's data.

Consistency is strong **within** a context and eventual **between** contexts: no operation
requires a single database transaction to span two contexts. Where a unified, cross-context
view is needed — a consolidated "land record" for a portal or a certificate — it is provided
as a **composed read model**, a projection built from the events of many contexts, which
holds no business rules and can be rebuilt from its sources. This is the technical expression
of the "Platform, not Aggregate" principle and of the composed-read-model escape hatch it
mandates.

## 3. Technology Baseline

The current frozen baselines define the following stack. Component substitutions are governed
by ADR and ship with pinned versions.

- **Backend:** Python with FastAPI, organised by bounded context, following a Unit-of-Work and repository pattern for transactional integrity within a context.
- **Frontend:** Next.js with TypeScript, presenting the four portals over a single governed API.
- **Data:** PostgreSQL as the system of record, with PostGIS for spatial data and row-level security (RLS) for tenant and record isolation.
- **Identity:** Keycloak or Auth0 as the identity provider, integrated through the platform's single authorisation path.
- **Payments:** Paystack as the payment integration, behind the Economic/Billing context's atomic ledger.
- **Storage:** S3-compatible object storage for evidence artefacts, with integrity controls applied by the Evidence context.
- **Infrastructure:** Docker for containerisation and Terraform for infrastructure-as-code; the cloud provider (for example AWS or Azure) remains an open decision to be fixed by ADR with version-pinned provider and resources.

## 4. Bounded-Context Architecture

The platform comprises thirteen contexts. Each owns its aggregates and data and integrates by
contract.

- **Identity** — participants, roles, organisation scoping, delegation; the source of authentication and the authorisation path. (Frozen: B1/B2.)
- **Registry** — the canonical parcel aggregate: parcel identity and numbering, ownership and status history, archival immutability.
- **Spatial Intelligence** — coordinate and polygon validation, coordinate reference systems, overlap detection, spatial indexing and tiling, on PostGIS.
- **Evidence** — upload, hashing, write-once (WORM) sealing, Merkle anchoring, and chain of custody.
- **Survey** — surveyor and firm licensing, assignment, survey-plan upload, and archive import.
- **Trust Engine** — per-parcel confidence derived from real signals, with fail-safe behaviour on insufficient data; full explainable multi-signal scoring is post-MVP.
- **Workflow** — the state-machine engine, sagas, timers, SLA and escalation, and compensation.
- **Community Trust** — attestation, consensus, conflict detection, and traditional-authority endorsement.
- **Inheritance & Customary Law** — death and beneficiary verification, share calculation, and certificates (post-MVP; PII-protected).
- **Economic/Billing** — the atomic ledger, invoicing, payment webhooks, and revenue-share consumption.
- **Knowledge Graph** — multi-hop relationship queries across contexts; read-only and rebuildable.
- **Security** — fraud detection, security incidents, and permission auditing.
- **Operations** — job queue, backup and recovery testing, and deployment observability.

## 5. Integration and Contracts

Contexts communicate through published domain events and defined interfaces. Integration
requirements are as follows: a context shall not read or write another context's datastore
directly; a context shall depend on another only through a versioned contract; where a
context must consume another's model, it shall translate at its boundary (an anti-corruption
translation) rather than adopt the foreign model internally; and cross-context consistency
shall be achieved through events and, where multi-step processes span contexts, through the
Workflow context's sagas and compensations rather than through distributed transactions. The
Knowledge Graph consumes events from all contexts as a read-only projection and never acts as
a write path.

## 6. Authorisation and Access Architecture

Access control is centralised and singular. All authorisation decisions resolve through one
Policy Decision Point / Policy Enforcement Point (PDP/PEP), informed by Policy Information
where required; the governing decision is recorded in ADR-004. No resource is reachable
except through this path, and no parallel, legacy, or surface-specific authorisation
mechanism is permitted, in accordance with Article X.3. Authentication is delegated to the
identity provider, with token lifecycle (issue, refresh, revoke) managed centrally.

Data isolation is enforced in the database by row-level security, so that authorisation is
defended at the surface **and** beneath it. Every new entity ships with its RLS/authorisation
policy in the same change that introduces it; a table without a policy is a defect, not a
work item for later. Every consequential action produces an immutable, attributable audit
record.

## 7. Evidence and Data-Integrity Architecture

Evidence is preserved so that its integrity is provable over time. On receipt, an artefact is
cryptographically hashed; it is then sealed write-once (WORM) with its metadata, timestamp,
and chain of custody; and it is anchored (for example via Merkle structures) so that any
later alteration is detectable. Sealed evidence is immutable: the architecture provides no
path to alter it in place, and integrity can be re-verified at any time. Record history is
retained and superseded rather than overwritten, consistent with the constitutional
requirement that history be amended rather than erased.

## 8. Spatial Architecture

Spatial data is held and processed in PostGIS. Boundary geometries are validated for
topological correctness and an explicit coordinate reference system before acceptance;
overlaps and conflicts against existing parcels are detected server-side; geometry is stored
append-only with exactly one active version and prior versions superseded; and spatial
indexing supports efficient query and map tiling. Spatial validation is a trust function: it
fails safe, rejecting invalid or ambiguous geometry rather than accepting it.

## 9. Read Models, Projections and CQRS

The platform separates its write model from its read model. Write models are the many
context-owned aggregates, each guarding its own invariants. Read models are projections built
from events for presentation and query — including the consolidated land-record view a portal
or certificate presents, and the Knowledge Graph's relationship queries. Read models own no
business rules, may be rebuilt from their source events, and never serve as a write path. This
separation is what lets the platform present a unified experience without a unified — and
therefore monolithic — write model.

## 10. Non-Functional Architecture

The architecture is required to scale by context rather than through a central bottleneck, so
that load in one domain does not degrade another, and to be assessable against defined load
tiers on the order of ten thousand, one hundred thousand, and one million users. Interactive
operations shall meet defined response-time targets, with queries optimised and free of N+1
patterns. The system shall be observable — through logging, metrics, and the audit trail —
sufficiently to investigate incidents. It shall be recoverable, with tested backup and restore
and a short, defined rollback window. Personal data shall be protected in proportion to
sensitivity, with particular controls around inheritance and family data.

## 11. Secure-by-Default Configuration

Security configuration fails safe. A missing required security setting halts startup rather
than defaulting to a permissive value; cross-origin policy, signing keys, and equivalent
controls have no permissive fallback. Secrets are never embedded in code or exposed, and are
supplied through managed configuration. These requirements exist because permissive defaults
and fallback development secrets were confirmed failure paths in a prior build; the detailed
security architecture is specified in LV-007.

## 12. Environments, Deployment and Delivery

The platform is developed across isolated environments (development, staging, production), each
provisioned through infrastructure-as-code. Delivery is continuous, gated by the platform's
quality model: changes pass automated tests observed to succeed, satisfy the Definition of
Done, and are deployable to staging with a rollback window on the order of two minutes before
production. Change is committed with discipline — one bounded context per change, with the
rationale recorded — and schema changes are reversible and ship with their matching
authorisation. No new production phase begins until the current phase has passed its mandatory
architecture, security, testing, performance, documentation, and deployment gates.

## 13. Traceability

Every technical requirement here answers to a product requirement in LV-005 and, above it, to
the Constitution. The context architecture and integration model implement Article X
(Platform-not-Aggregate; integration by contract). The authorisation and RLS architecture
implement Article X.3 and the platform's authorisation rule. The evidence-integrity and
history-preservation architecture implement the mission's preservation duty (Article IV) and
the amend-don't-erase principle. The fail-safe spatial and trust behaviour implements the
engineered-trust mandate (Article II.3). Where this document and a higher document could be
read to differ, the higher document prevails, and this document is reconciled through a
recorded ADR.

---

*End of LV-006 — Technical Requirements Document (Draft v0.1). Governed by LV-000 (v1.7) and LV-005. Submitted for review.*
