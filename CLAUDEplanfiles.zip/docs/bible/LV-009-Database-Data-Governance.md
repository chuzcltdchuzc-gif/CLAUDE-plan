# The Official LandVault Bible™

## Volume LV-009 — Database & Data Governance

*A subordinate volume of The Official LandVault Bible™, governed by LV-000 — The LandVault Constitution.*

---

## Document Control

| Field | Entry |
|---|---|
| **Document ID** | LV-009 |
| **Title** | Database & Data Governance |
| **Library** | The Official LandVault Bible™ |
| **Tier** | Bible (subordinate to the Constitution; elaborated by ADRs) |
| **Version** | v0.1 (Draft for Review) |
| **Status** | Draft — Under Authorship |
| **Classification** | Public (Governance) |
| **Owner** | Office of the LandVault Constitution (Governance Authority) |
| **Governed By** | LV-000 (v1.7); LV-006 (TRD); LV-007 (Security) |
| **Governs** | Data models, storage, migrations, retention, and data-governance procedures |
| **Source Baselines** | Development-Plan repository — PostgreSQL+PostGIS, RLS, Evidence integrity (hash/WORM/Merkle), Economic/Billing atomic ledger, Engineering Rules, DoD |
| **Review Cycle** | Per milestone, or upon a data-relevant ADR |
| **Language** | English (UK) |

*Subordinate to LV-000, LV-006, and LV-007. This volume governs how data is owned, stored,
protected, retained, and evolved. It applies the platform's principles to its most valuable and
most sensitive asset: the land record and its evidence.*

---

## 1. Purpose and Scope

This volume defines the platform's data architecture and its data-governance regime: how data
is owned and isolated by context, how the canonical land record and its evidence are stored and
kept provably intact, how integration data flows without coupling contexts, how data is
classified, protected, retained, and traced, and how schema change is governed. It exists so
that the platform's data can be trusted over the long term — which is, ultimately, the platform's
entire purpose.

## 2. Data Ownership by Context

Data ownership follows the platform's architecture: **each bounded context owns its own data,
and no context reads or writes another's store.** Each context's data is isolated —
by separate schema or database per context — so that ownership is enforced technically, not only
by convention. There are **no cross-context foreign keys**; a context references another context's
entity by identity (for example a `parcel_id`) and resolves it through the owning context's
contract. This is the data-layer expression of Article X: it prevents the silent emergence of a
single coupled schema — a "God database" — that would be as damaging as a God Aggregate.

## 3. The Canonical Record and Master Identity

The **Registry** context is the system of record for parcel identity: it owns parcel numbering,
uniqueness (no duplicate parcel number within a tenant), ownership and status history, and
archival immutability. Parcel identity is the platform's master data — the single identifier by
which Spatial, Evidence, Survey, and other contexts refer to a parcel without absorbing its
record. Ownership and status are **append-only histories**: a change adds a new state and
supersedes the prior one; it never overwrites, consistent with the constitutional requirement
that history be amended rather than erased.

## 4. Spatial Data

Spatial data is held in **PostgreSQL with PostGIS**. Geometries are stored with an explicit
coordinate reference system and validated for topological correctness before persistence.
Boundaries are **versioned and append-only**, with exactly one active version and prior versions
retained as superseded; overlaps and conflicts are computed against stored geometries. Spatial
indexes support efficient query and map tiling. Spatial persistence is a trust function:
invalid or ambiguous geometry is rejected at write time rather than stored and trusted later.

## 5. Evidence Storage and Integrity

Evidence artefacts are held in **S3-compatible object storage**, with their integrity metadata
governed by the **Evidence** context. On receipt an artefact is cryptographically hashed; it is
sealed **write-once (WORM)** together with its metadata, timestamp, and chain of custody; and it
is **anchored** (for example through Merkle structures) so that any later alteration is
detectable. The database holds the integrity references and custody chain; the object store holds
the artefact. Sealed evidence is immutable — the data architecture provides no in-place update
path — and its integrity is re-verifiable at any time. This is the mechanism by which the
platform can prove, years later, that a piece of evidence is exactly what it was when recorded.

## 6. Integration Data and the Event Log

Contexts integrate through **domain events**, not shared tables. Published events form an
append-only log that is the substrate for cross-context consistency, for read models, and for the
Knowledge Graph. Because integration flows through events rather than shared schema, contexts
remain independently evolvable, and consistency between them is eventual and observable rather
than enforced by distributed transaction. The event log is itself governed data: it is retained,
ordered, and auditable.

## 7. Read Models and Derived Stores

Read models — including the consolidated land-record view and the **Knowledge Graph** — are
**derived, rebuildable projections** built from the event log. They own no authoritative state and
no business invariants, and they are never a write path back into the contexts. Because they are
rebuildable, they are not points of irreplaceable data: if a projection is lost or its shape
changes, it is reconstructed from its sources. This separation lets the platform serve rich,
unified queries without creating a second, competing system of record.

## 8. Financial Data Integrity

The **Economic/Billing** context maintains an **atomic ledger**. Balances change only through
authorised, audited, atomic transactions; the data model provides no path for a user to alter a
balance directly, closing the self-service financial-fraud vector confirmed in a prior build.
Invoices, payments, and revenue-share consumption are recorded so as to be reconcilable, and
payment-provider webhooks are verified before they affect ledger state.

## 9. Data Classification and Protection

All data is classified by sensitivity, and controls are applied in proportion. Public governance
information, operational data, personal information, and sensitive family and inheritance data
are treated distinctly, with the most sensitive receiving the strongest controls. **Row-level
security** enforces tenant and record isolation in the database itself, so that isolation holds
even if an application-layer flaw occurs; every table holding protected data carries its RLS
policy from the moment it exists (Engineering Rule 1). Access to personal data flows through the
single authorisation path and is auditable. Encryption in transit and at rest, and managed secret
storage, protect data confidentiality; no secret is embedded in schema, code, or logs.

## 10. Retention, Provenance and Lineage

The platform retains what it must to remain trustworthy over time, and records where data came
from. Land records and their evidence are retained with their full history and provenance, so that
the origin and chain of custody of any record can be established. Superseded states are kept rather
than deleted. Personal data is retained only as long as its purpose and the applicable rules
require, balancing the duty to preserve the land record against the duty to protect the
individual. Data lineage — which source and which events produced a given record or projection —
is traceable, so that the platform can always answer how it came to hold what it holds.

## 11. Schema Evolution and Migrations

Schema change is governed. Every migration is **reversible** and is **rollback-tested** before
production, and it ships **with its matching authorisation/RLS policy in the same change**
(Engineering Rules 1 and 7). A new entity without a policy is a non-waivable blocker. Migrations
follow the platform's commit discipline — one bounded context at a time, with the rationale (Rule 8)
recorded — and significant data-model decisions are captured as ADRs. History is preserved through
change: migrations amend the model; they do not erase the record.

## 12. Backup, Recovery and Continuity

The platform's data is protected by **tested** backup and recovery — not assumed, but exercised —
with restoration to defined recovery-point and recovery-time objectives. The Operations context
owns backup and recovery testing and deployment observability. Because read models are rebuildable
and integration runs through a retained event log, recovery focuses on the authoritative
context stores and the event log, from which derived state can be reconstructed.

## 13. Data Governance Roles and Accountability

Data is governed, not merely stored. Ownership of each context's data is explicit and
accountable; changes to shared concerns — classification, retention, integrity controls — proceed
through governed decision rather than local discretion. The Security context provides permission
auditing to detect access drift, and the audit trail makes data access and change attributable.
Data-governance decisions are recorded so that the platform's stewardship of its most important
asset is itself transparent and reviewable.

## 14. Traceability

The data architecture implements the Constitution: context-owned, non-cross-referenced stores
implement Article X; append-only histories and preserved provenance implement the mission's
preservation duty and the amend-don't-erase principle (Article IV; §E.3); RLS and classification
implement the platform's authorisation and protection rules; the atomic ledger and its integrity
support the Trust Neutrality Firewall (Article XV.1); and evidence integrity implements the
engineered-trust mandate (Article II.3). Where this document and a higher document could be read
to differ, the higher document prevails, reconciled through a recorded ADR.

---

*End of LV-009 — Database & Data Governance (Draft v0.1). Governed by LV-000 (v1.7), LV-006, and LV-007. Submitted for review.*
