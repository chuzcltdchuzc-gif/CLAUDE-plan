# The Official LandVault Bible™

## Volume LV-010 — Design System

*A subordinate volume of The Official LandVault Bible™, governed by LV-000 — The LandVault Constitution.*

---

## Document Control

| Field | Entry |
|---|---|
| **Document ID** | LV-010 |
| **Title** | Design System |
| **Library** | The Official LandVault Bible™ |
| **Tier** | Bible (subordinate to the Constitution; elaborated by design assets and ADRs) |
| **Version** | v0.1 (Draft for Review) |
| **Status** | Draft — Under Authorship |
| **Classification** | Public (Governance) |
| **Owner** | Office of the LandVault Constitution (Governance Authority) |
| **Governed By** | LV-000 (v1.7); LV-002 (clarity value); LV-005 (PRD); consistent with LV-008 |
| **Governs** | LV-011 (UX Standards) and all interface implementation |
| **Source Baselines** | Development-Plan repository — Next.js/TypeScript frontend, four portals; DoD accessibility expectations |
| **Review Cycle** | Per release, or upon ratification of brand tokens |
| **Language** | English (UK) |

*Subordinate to LV-000. Where this document proposes concrete visual values (colour,
type), they are **proposed defaults pending brand ratification** and are marked as such;
they carry no authority until adopted. The design principles, by contrast, derive from the
Constitution and are binding on any interface the platform ships.*

---

## 1. Purpose and Scope

This volume defines the LandVault design system: the principles, foundations, components, and
patterns from which every interface is built, so that the platform presents one coherent,
accessible, and trustworthy experience across its four portals. It governs the visual and
interaction foundations; the UX standards that apply them to journeys are specified in LV-011.

## 2. Design Principles

The platform's interface is an instrument of trust, and its design principles follow from the
Constitution rather than from fashion.

**Clarity above all.** Interfaces must be intelligible to non-expert citizens as well as
professionals and officials (the clarity value of LV-002). Plain language, obvious hierarchy,
and the removal of unnecessary complexity are requirements, not preferences.

**Honesty about confidence.** The interface never overstates what the platform knows. Where
evidence is insufficient, the design shows insufficiency plainly; it never renders an
unearned "verified" or a fabricated score as if it were established fact. This is the visual
expression of the platform's fail-safe rule and its candour value.

**Evidence forward.** The design surfaces provenance — where a record came from, what supports
it, and on whose authority — so that trust can be examined rather than merely presented.

**Calm and professional.** The platform is public infrastructure, not a consumer game. The
aesthetic is restrained, serious, and free of manipulative or persuasive patterns; it never
uses urgency, dark patterns, or persuasive design to drive action.

**Inclusive by default.** The design assumes a wide range of devices, connection qualities,
literacy levels, and abilities, and is built to serve them from the outset rather than as an
afterthought.

**One system, many audiences.** A single design system underlies all four portals; audiences
differ in their tasks and emphasis, not in the integrity or quality of the experience.

## 3. Foundations (Design Tokens)

The design system is expressed as **tokens** — named, versioned values that are the single
source of truth for visual style, consumed by the Next.js/TypeScript front end. The token
categories below are binding as a structure; the specific values are proposed defaults pending
brand ratification.

- **Colour.** A restrained palette with clearly defined semantic roles — surface, text, primary action, and status (success/verified, warning/pending, error/rejected, and a distinct neutral for *insufficient data*). Every foreground/background pair must meet the accessibility contrast requirements of §4. *(Specific hex values: proposed defaults pending brand ratification.)*
- **Typography.** A readable type scale with a limited set of roles (display, heading, body, caption), chosen for legibility at small sizes and on low-quality screens. *(Specific typefaces: proposed defaults pending brand ratification.)*
- **Spacing & layout.** A consistent spacing scale and a responsive grid that adapts from small mobile screens upward.
- **Elevation, radius, borders.** A small, consistent set expressing hierarchy without ornament.
- **Motion.** Minimal, purposeful motion that communicates state change; never decorative motion that delays or distracts, and always respectful of reduced-motion preferences.
- **Iconography.** A single, consistent icon set with text labels; icons never carry meaning alone.

Tokens are the source of truth: no interface hard-codes a style value that a token should
express, so that a change to the system propagates consistently and is governed centrally.

## 4. Accessibility Standards

Accessibility is a requirement, consistent with the clarity value and the platform's duty to
serve all who rely on it. Interfaces conform, at minimum, to **WCAG 2.1 AA**: text and meaningful
non-text elements meet AA contrast ratios; all functionality is operable by keyboard; content is
usable by screen readers with correct semantics and labels; colour is never the sole carrier of
meaning; targets are adequately sized for touch; and reduced-motion and text-scaling preferences
are honoured. Given the platform's context, design is **mobile-first and low-bandwidth-aware**:
core journeys function on modest devices and constrained connections, degrade gracefully, and
avoid heavy assets on critical paths.

## 5. Component Library

The platform is built from a shared library of components, each defined with its full set of
states — including, explicitly, **loading, empty, error, and insufficient-data** states, which
are treated as first-class rather than afterthoughts. Core components include navigation and the
portal shell; forms and inputs with inline validation; data display for parcels, evidence, and
status; the status and confidence indicators of §6; document upload and preview; tables and
lists with authorised, scoped results; dialogs and confirmations for consequential actions; and
notifications. Every component is accessible by construction and consumes tokens rather than
bespoke styles.

## 6. Trust and Confidence UI Patterns

The most important patterns in the system are those that communicate trust, because misrepresenting
confidence would violate the platform's founding principle. Three rules govern them.

**Status is honest and specific.** Verification and record status are shown with clear,
distinct states — for example verified, pending, in progress, disputed, and *insufficient
evidence* — each visually distinct and never conflated. A pending or insufficient state is never
styled to resemble a completed, favourable one.

**Insufficient data has its own treatment.** Where the platform lacks the evidence to assert
confidence, the interface displays a distinct *insufficient-data* state — neutral, unmistakable,
and never a reassuring green — directly expressing the fail-safe rule at the surface.

**Provenance and authority are attributable.** Where the platform presents an assurance — a
verification, a certificate, a badge — the interface makes traceable the evidence and the
statutory or professional authority behind it, and never implies that LandVault itself
determined ownership or title (Article XV.2). Commercial elements (pricing, marketplace) are
visually and functionally separated from evidentiary displays, so that no commercial cue can be
mistaken for an evidentiary fact (Article XV.1).

## 7. Multi-Portal Consistency

All four portals — Customer, Partner, Enterprise, Government — are built from the same design
system. They may differ in information density, default views, and emphasis appropriate to their
audience, but they share one set of foundations, one component library, and one standard of
accessibility and honesty. A participant moving between contexts encounters a consistent, coherent
platform, not four unrelated products.

## 8. Content and Localisation

Language is part of the design. Content is written in plain, direct language (UK English as the
base), avoiding jargon and legalese where a citizen must understand it. The system is built to
support localisation — additional languages, local numerals and formats, and the Nigerian Naira
(₦) as currency — so that the platform can serve its users in terms they understand. Content
patterns favour clarity and honesty over persuasion, consistent with the platform's neutrality.

## 9. Governance of the Design System

The design system is versioned and governed like the rest of the platform. Tokens and components
are the single source of truth; changes to them are recorded and propagate centrally rather than
being reimplemented per screen. Brand ratification — the adoption of concrete colour and type
values — is itself a governed decision, recorded when made, after which the proposed defaults in
this volume are replaced by the ratified values. Significant design decisions are captured as
ADRs, subordinate to this document and to the Constitution.

## 10. Traceability

The design system implements the Constitution: its clarity and inclusion principles implement the
clarity value (LV-002) and the duty to serve all who rely on the platform (Article I.3); its
honest-confidence and insufficient-data patterns implement the fail-safe mandate (Article II.3)
and the candour value; its separation of commercial from evidentiary display implements the Trust
Neutrality Firewall (Article XV.1); and its attributable-authority patterns implement Delegated
Authority (Article XV.2). Where this document and a higher document could be read to differ, the
higher document prevails.

---

*End of LV-010 — Design System (Draft v0.1). Governed by LV-000 (v1.7). Submitted for review.*
