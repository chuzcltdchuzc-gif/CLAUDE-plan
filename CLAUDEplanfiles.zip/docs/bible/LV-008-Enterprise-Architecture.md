# The Official LandVault Bible™

## Volume LV-008 — Enterprise Architecture

*A subordinate volume of The Official LandVault Bible™, governed by LV-000 — The LandVault Constitution.*

---

## Document Control

| Field | Entry |
|---|---|
| **Document ID** | LV-008 |
| **Title** | Enterprise Architecture |
| **Library** | The Official LandVault Bible™ |
| **Tier** | Bible (subordinate to the Constitution; elaborated by ADRs) |
| **Version** | v0.1 (Draft for Review) |
| **Status** | Draft — Under Authorship |
| **Classification** | Public (Governance) |
| **Owner** | Office of the LandVault Constitution (Governance Authority) |
| **Governed By** | LV-000 (v1.7); LV-006 (TRD); consistent with LV-003, LV-007 |
| **Governs** | Cross-cutting architecture standards and integration governance |
| **Source Baselines** | Development-Plan repository — 13 bounded contexts, stack, Phase Gates, infra (Docker/Terraform) |
| **Review Cycle** | Per phase gate (architecture review), or upon a governing ADR |
| **Language** | English (UK) |

*Subordinate to LV-000 and LV-006. The TRD (LV-006) specifies the architecture of the
platform's internals; this document takes the enterprise view — how the whole system fits
together, how it meets the outside world, and how its architecture is governed over time.*

---

## 1. Purpose and Scope

This volume describes LandVault as an enterprise system: its overall structure, the map of
its bounded contexts and their relationships, the surfaces through which participants reach it,
the external institutions it integrates with, the concerns that cut across every context, the
topology in which it is deployed, and the governance by which its architecture evolves without
losing coherence. It is written for architects, senior engineers, enterprise and government
integration partners, and procurement and investment reviewers who need to understand the
system as a whole.

## 2. Architectural Principles Applied

The enterprise architecture is a direct application of the platform's constitutional
principles. LandVault is a **platform of independent bounded contexts** (Article X): the
enterprise design optimises for context independence, contract-based integration, and the
protection of the trusted kernel, rather than for a single unified application. Every surface
resolves through **one authorisation path** (Article X.3). The **trust functions are
firewalled from commercial functions** (Article XV.1) at the architectural level, not merely by
policy. And the architecture is **kernel-first** (Article X.4): identity, registry, spatial,
and evidence are architected and hardened before the business layers that depend on them.

## 3. The Layered Enterprise View

At the enterprise level the platform is organised into five layers, each realised by one or
more bounded contexts and consumed through defined surfaces.

- **Layer 1 — Identity & Trust:** the Identity context; the root of authentication, authorisation, delegation, and audit for the whole platform.
- **Layer 2 — Land Intelligence (the kernel):** Registry, Spatial Intelligence, and Evidence; the canonical substance the platform preserves.
- **Layer 3 — Marketplace:** Survey and Economic/Billing today, with a dedicated Marketplace context as strategic direction (LV-003); the adoption engine.
- **Layer 4 — Enterprise Services:** managed access, bulk dispatch, and programmatic interfaces for institutional consumers.
- **Layer 5 — Government Integration:** connections to statutory land authorities.

Supporting every layer are the cross-cutting contexts — Trust Engine, Workflow, Community
Trust, Knowledge Graph, Security, and Operations — and the Inheritance & Customary-Law context
at the higher tiers.

## 4. Context Map

The context map records how contexts relate and integrate. The pattern throughout is
**customer/supplier with published contracts and boundary translation**: a consuming context
depends on a producing context's published events and interfaces, and translates them at its
own boundary rather than adopting the producer's model internally (an anti-corruption
translation). Identity is an **upstream supplier** to every context. Registry is the
**canonical source of parcel identity**, referenced by Spatial, Evidence, Survey, Trust
Engine, and others by `parcel_id`. The Knowledge Graph is a **downstream, read-only consumer**
of events from all contexts and supplies query capability without ever writing back. The
Workflow context **orchestrates** multi-context processes through sagas and compensations, so
that no long-running process requires a distributed transaction.

## 5. Access Surfaces (Portals as BFFs)

Participants reach the platform through four portals — Customer, Partner, Enterprise, and
Government — each implemented as a **backend-for-frontend (BFF)**: a presentation and
composition layer over the governed contexts, not a new domain or security model. Every portal
authenticates and authorises through the single Identity path (Article X.3); a portal composes
read models and invokes context interfaces but never bypasses their controls. This lets each
audience receive a fit-for-purpose experience while the platform maintains exactly one place
where access is decided.

## 6. External Integration Landscape

LandVault is not a closed system; its value depends on trustworthy connections to external
institutions, each mediated by contract and by the appropriate context.

- **Statutory land authorities** (surveyor-general offices, state land registries, planning and compliance bodies) integrate through the Government layer; LandVault supports and is authorised by them and asserts no authority they have not delegated (Article XV.2).
- **Financial institutions** (banks, mortgage providers, insurers) integrate through the Enterprise layer for bulk verification and dispatch, consuming verification outcomes through managed, audited interfaces.
- **Payment providers** (Paystack) integrate behind the Economic/Billing context's atomic ledger, with webhook verification.
- **Identity providers** (Keycloak/Auth0) provide authentication behind the single authorisation path.
- **Object storage** (S3-compatible) holds evidence artefacts under the Evidence context's integrity controls.

Each external integration is versioned, authenticated, audited, and isolated so that a failure
or compromise at a boundary cannot propagate into the kernel.

## 7. Cross-Cutting Concerns

Certain concerns span every context and are architected once, consistently. **Identity and
access** are centralised in the single authorisation path with database row-level isolation.
**Auditability** is universal: every consequential action is recorded immutably and
attributably. **Observability** — logging, metrics, tracing — is standardised so the whole
system can be watched and incidents investigated. **Data protection** applies classification
and proportionate controls everywhere, with heightened care for personal and family data.
**Configuration** fails safe across the platform. And **eventing** is a shared backbone: contexts
publish and consume domain events through a consistent mechanism, which is also the substrate
for read models and the Knowledge Graph.

## 8. Deployment Topology and Environments

The platform is containerised (Docker) and provisioned through infrastructure-as-code
(Terraform), across three isolated environments — development, staging, and production — so
that changes are proven before they reach users. The cloud provider is an open decision to be
fixed by ADR with version-pinned provider and resources. Contexts are deployable and scalable
independently, so that load or change in one does not compel redeployment or degradation of
another. Delivery is continuous and gated: a change reaches production only after observed
passing tests, a satisfied Definition of Done, and staging deployment with a short rollback
window.

## 9. Scalability, Availability and Resilience

Because contexts are independent and integrate by event and contract, the platform scales
**horizontally by context** rather than through a single bottleneck, and is assessed against
defined load tiers on the order of ten thousand, one hundred thousand, and one million users.
Resilience follows the same grain: a degraded context should fail in isolation, with the
Workflow context's compensations preserving consistency across long-running processes, and with
tested backup and recovery restoring state within defined windows. The Knowledge Graph and
other read models, being rebuildable projections, can be reconstructed from their source events
rather than being points of irreplaceable state.

## 10. Architecture Governance

The architecture evolves under governed discipline rather than drift. Significant decisions are
recorded as **Architecture Decision Records**, each referencing the decisions it builds upon and
never contradicting the Constitution; changes to frozen work proceed only through such records.
Every phase gate includes a mandatory architecture review, and progress to a new phase is earned
by verified quality against the standing questions — architectural alignment, security,
scalability, cost, coverage, documentation, rollback, defect status, AI evaluation, and
future-proofing. In this way the enterprise architecture remains coherent as the platform grows
from its frozen kernel toward national-scale infrastructure.

## 11. Traceability

The enterprise architecture implements the Constitution directly: the context map and
integration model implement Article X; the single-authorisation-path portals implement Article
X.3; the firewalled commercial integrations implement Article XV.1; the delegated, contract-
bound government integrations implement Article XV.2; and the kernel-first topology implements
Article X.4. Where this document and a higher document could be read to differ, the higher
document prevails, reconciled through a recorded ADR.

---

*End of LV-008 — Enterprise Architecture (Draft v0.1). Governed by LV-000 (v1.7) and LV-006. Submitted for review.*
