# The Official LandVault Bible™

## Foundational Charter — LV-000

# The LandVault Constitution

---

*Status: RATIFIED — v1.7 (Complete Consolidated Text, incorporating Amendments 1–7)*
*Publication Status: Ratified, Binding Instrument*
*Classification: Public (Governance)*
*Authority Level: Constitutional (Highest)*
*Supersedes: None*
*Governs: All LandVault documentation and platform decisions*
*Enacted: 20 July 2026 (First Edition — Foundation) · Amendments 1–2 ratified 26 July 2026 · Amendments 3–7 ratified 26 July 2026 (structure complete, Parts I–V) · Future changes enter by constitutional amendment*

---

# Phase 0 — Cover, Document Control & Publication Standards

## Title Page

**THE OFFICIAL LANDVAULT BIBLE™**

**Foundational Charter**

**LV-000 — The LandVault Constitution**

*The enduring principles that govern the LandVault platform and every decision made within it.*

---

## Document Control

| Field | Entry |
|---|---|
| **Document ID** | LV-000 |
| **Title** | The LandVault Constitution |
| **Library** | The Official LandVault Bible™ (Constitutional Library) |
| **Volume** | Foundation — Part I of the Constitutional Series |
| **Version** | v1.7 (Complete Consolidated Text — incorporates Amendments 1–7; Parts I–V structurally complete) |
| **Status** | Ratified — Binding Constitutional Instrument |
| **Editions** | First Edition — Foundation (Phase 0 + Articles I–IV, 20 Jul 2026); Amendments 1–2 (Articles V, X, XV.1–2); Amendments 3–7 (Article VI; Articles VII–IX, XI–XIV, XV.3–5; Part III XVI–XX; Part IV Commitments; Part V Declaration) — all ratified 26 Jul 2026 |
| **Enacted On** | 20 July 2026 (Foundation) · 26 July 2026 (Amendments 1–7) |
| **Amendment Basis** | Further Articles and Parts enter only by constitutional amendment |
| **Classification** | Public (Governance) |
| **Authority Level** | Constitutional (Highest) |
| **Owner** | Office of the LandVault Constitution (Governance Authority) |
| **Approving Body** | LandVault Governance Board |
| **Supersedes** | None |
| **Governs** | The Bible, ADRs, Product, Technical, Implementation, and Operations documentation |
| **Review Cycle** | Annual, or upon a constitutional amendment event |
| **Language** | English (UK) |
| **Date Initiated** | 19 July 2026 |

## Revision History

| Version | Date | Author | Summary of Change | Approval |
|---|---|---|---|---|
| v0.1 | 19 Jul 2026 | Constitutional Authorship | Initial foundational draft — Phase 0 and Article I | Pending |
| v0.2 | 19 Jul 2026 | Constitutional Authorship | Added Article II — Why LandVault Exists (grounded in Development-Plan repository) | Pending |
| v0.3 | 19 Jul 2026 | Constitutional Authorship | Added Article III — Vision | Pending |
| v0.4 | 19 Jul 2026 | Constitutional Authorship | Added Article IV — Mission | Pending |
| **v1.0** | **20 Jul 2026** | **Constitutional Authorship** | **Ratified as First Edition — Foundation (Phase 0 + Articles I–IV). Added Enactment & Amendment clause. Subsequent Articles enter by amendment.** | **Ratified** |
| **v1.1** | **26 Jul 2026** | **Constitutional Authorship** | **Amendment 1 (ratified)** — adopted Article V — Purpose into Part I — Foundation. | **Ratified** |
| **v1.2** | **26 Jul 2026** | **Constitutional Authorship** | **Amendment 2 (ratified)** — adopted Article X (Architectural Principles) and Article XV.1–XV.2 (Trust Neutrality Firewall; Delegated Authority) into Part II. Occasioned by the multi-sided platform / marketplace reframing. | **Ratified** |
| **v1.3** | **26 Jul 2026** | **Constitutional Authorship** | **Amendment 3 (ratified)** — adopted Article VI (Strategic Promise), completing Part I. | **Ratified** |
| **v1.4** | **26 Jul 2026** | **Constitutional Authorship** | **Amendment 4 (ratified)** — adopted Articles VII (Core Values), VIII (Product), IX (Engineering) into Part II. | **Ratified** |
| **v1.5** | **26 Jul 2026** | **Constitutional Authorship** | **Amendment 5 (ratified)** — adopted Articles XI (Security), XII (Data), XIII (AI), XIV (Ethical), and XV.3–XV.5 (Governance), completing Part II. | **Ratified** |
| **v1.6** | **26 Jul 2026** | **Constitutional Authorship** | **Amendment 6 (ratified)** — adopted Part III (Articles XVI–XX, Constitutional Governance). | **Ratified** |
| **v1.7** | **26 Jul 2026** | **Constitutional Authorship** | **Amendment 7 (ratified)** — adopted Part IV (Constitutional Commitments) and Part V (Constitutional Declaration). Constitution structurally complete. | **Ratified** |

## Approval Record

| Role | Name | Signature | Date |
|---|---|---|---|
| Constitutional Author | Constitutional Authorship | Recorded | 20 Jul 2026 |
| Ratifying Authority (Platform Owner) | LandVault Governance Authority | Ratified | 20 Jul 2026 |
| Governance Board Chair | *(reserved for countersignature)* | — | — |

*This First Edition — Foundation was ratified by the LandVault Governance Authority on 20 July 2026 and is a binding constitutional instrument from that date. The Governance Board Chair line is reserved for formal countersignature; it does not affect the binding force of this edition.*

---

## Publication Standards

Every document published within The Official LandVault Bible™, and every document
governed by it, shall carry the following control fields without exception:

- **Document ID** — a unique, permanent identifier (e.g. LV-000).
- **Version** — a semantic version treated with the same discipline as software.
- **Classification** — the intended audience and disclosure level.
- **Owner** — the accountable role responsible for the document's integrity.
- **Review Cycle** — the interval at which the document must be re-examined.
- **Approval Record** — the authority under which the document was ratified.
- **Revision History** — a complete, append-only account of every change.
- **Cross-References** — links to superior, subordinate, and related documents.
- **Change Log** — a plain-language summary of what changed and why.

No document may enter the Bible, or be treated as authoritative, until these fields
are complete and correct.

## Versioning Standard

Documentation shall be versioned as software is versioned. History is never
rewritten; it is amended. When the platform evolves, the governing document is
updated through the established governance process, and the change is recorded in
the Revision History and Change Log rather than silently replaced. A document at
version v1.0 is a ratified, binding instrument; a document below v1.0 is a
controlled draft that guides authorship but does not yet bind the platform.

## Constitutional Publishing Rule

From the adoption of LV-000, the following hierarchy shall govern the LandVault
platform:

```
        The LandVault Constitution (LV-000)
                        │
                        ▼
            The Official LandVault Bible
                        │
                        ▼
        Architecture Decision Records (ADRs)
                        │
                        ▼
              Product Documentation
                        │
                        ▼
             Technical Documentation
                        │
                        ▼
                 Implementation
                        │
                        ▼
                   Operations
```

No lower-level document may contradict a higher-level document. Where a conflict
exists, the higher-level document prevails until the lower-level document is
formally reconciled with it, or the higher-level document is itself amended
through the established governance process. This hierarchy exists to ensure
consistency, traceability, accountability, and the long-term stewardship of the
platform.

## The Six Tests of Constitutional Authorship

Every article in LV-000 must satisfy six tests before it may be accepted:

1. **Truth** — It accurately reflects the purpose and capabilities of LandVault, and makes no unsupported claim.
2. **Longevity** — It remains valid across many years, independent of any specific technology, vendor, or feature.
3. **Clarity** — It is understandable to technical and non-technical audiences alike, including government officials, investors, and engineers.
4. **Consistency** — It aligns with the approved Architecture Decision Records and the established LandVault architecture.
5. **Governance** — It provides guidance for future decisions rather than describing transient implementation detail.
6. **Stewardship** — It reinforces LandVault's responsibility to preserve trust, evidence, and public confidence.

---

# Part I — Foundation

## Article I — Preamble

### I.1 — Recital of Purpose

Land is among the oldest and most consequential records that any society keeps. On
the certainty of who holds what, and on what evidence, rests the security of homes,
the willingness to invest, the fairness of taxation, the resolution of disputes, and
the confidence of communities in the institutions that serve them. Where that
certainty is strong, people build, lend, trade, and plan. Where it is weak, the
consequences fall hardest on those with the least power to defend their claims.

LandVault is established in recognition of a single, enduring truth: that the value
of a land record lies not in the fact that it has been stored, but in the fact that
it can be trusted. Accordingly, LandVault exists to preserve trust in land
information — not merely to digitize land records.

This principle, adopted as Constitutional Principle No. 1, is the origin from which
every other provision of this Constitution proceeds.

### I.2 — What LandVault Is, and What It Is Not

LandVault is a platform for preserving, organising, verifying, and governing
land-related evidence and registry information. It is designed to strengthen the
trustworthiness of land information over time, to make the provenance of that
information visible, and to hold the systems that manage it to a consistent standard
of integrity.

LandVault does not, by its own authority, determine or adjudicate the ownership of
land. The determination of legal ownership is a function of law and of the lawful
authorities to whom that function belongs. LandVault serves those authorities and
the people they govern by safeguarding the evidence, records, and processes upon
which such determinations rely. It records and preserves what is asserted, by whom,
on what basis, and when; it does not substitute its judgement for that of the
competent authority.

This distinction is deliberate and foundational. It defines the boundary of the
platform's responsibility and the limit of its authority, and it shall not be
weakened by any future feature, policy, or interpretation.

### I.3 — Whom LandVault Serves

LandVault is built to serve, without displacing the proper authority of any of them:

- **Governments and public institutions**, as the lawful custodians of land administration, to whom LandVault offers a disciplined, auditable, and sovereign-respecting foundation for the records they hold.
- **Communities**, whose collective histories, boundaries, and customary arrangements deserve to be recorded faithfully and preserved against loss.
- **Citizens**, for whom the security of a claim to land is often the security of a home, a livelihood, and a legacy.
- **Professional users** — including surveyors, registrars, legal practitioners, and administrators — whose work depends on records that are complete, verifiable, and reliable.
- **Financial and investment institutions**, whose confidence in land information underpins lending, valuation, and long-term commitment of capital.
- **Future generations**, who inherit both the records we preserve and the trust, or mistrust, that our stewardship earns.

Where the interests of these parties are in tension, LandVault resolves that tension
in favour of preserving trust and protecting the integrity of the record, so that
no party is served at the cost of the confidence on which all of them depend.

### I.4 — The Foundational Commitments

In establishing LandVault, the following commitments are affirmed as the enduring
obligations of the platform. They bind not a version of the product, but the
platform itself, for as long as it exists:

1. **To preserve trust before all else.** Every capability shall strengthen, and none shall knowingly weaken, the trustworthiness of land information.
2. **To respect the authority of law and of legitimate institutions.** LandVault supports lawful land administration; it does not usurp it.
3. **To preserve evidence faithfully.** The provenance, history, and integrity of records shall be safeguarded, and history shall be amended through governed process rather than erased.
4. **To serve transparently.** Those who rely on the platform are entitled to understand how information is preserved, verified, and governed.
5. **To protect the vulnerable.** The platform shall not become an instrument by which the powerful dispossess the powerless of their rightful claims.
6. **To endure.** LandVault is built to remain trustworthy across changes of technology, organisation, and generation.

### I.5 — The Authority of This Constitution

This Constitution is the highest instrument of the LandVault platform. From its
adoption, every Product Requirement, Technical Requirement, Architecture Decision
Record, Security Policy, Design Standard, Business Strategy, and Operational
Procedure shall be interpreted in harmony with it, and no such instrument shall
stand where it contradicts this Constitution until reconciled through the
governance process the Constitution establishes.

Where the platform evolves, this Constitution shall provide continuity. Where new
capabilities emerge, it shall provide direction. Where difficult decisions arise, it
shall provide the principles by which those decisions are made.

Upon these foundations, the remaining Articles of this Constitution are established.

---

## Article II — Why LandVault Exists

### II.1 — The Problem in the World

In many jurisdictions, the record of who holds land, and on what basis, is
incomplete, contested, fragmented across incompatible systems, or vulnerable to
manipulation. Boundaries are disputed; inheritances are unresolved; customary and
statutory claims sit uneasily beside one another; and paper records are lost,
duplicated, or altered without trace. Where the record cannot be trusted, the
consequences are not abstract. Families lose homes they have held for generations.
Investment is withheld from places that most need it. Disputes escalate because no
neutral, reliable record exists to settle them. Those with power can assert claims
that those without power cannot contest.

LandVault exists because this problem is real, consequential, and solvable — and
because the institutions responsible for land administration deserve tools that make
their records more trustworthy rather than merely more digital.

### II.2 — The Failure of Assumed Trust

LandVault exists also because of a lesson learned directly, and at cost. The present
platform is not a first attempt. It follows two predecessor builds, each of which
appeared functional and each of which was found, upon audit, to be untrustworthy in
ways that matter most for land information:

- Authorisation that was enforced only at the surface, leaving the underlying records exposed beneath it.
- Records that lacked isolation between the parties entitled to them, so that the boundary between one holder's information and another's could not be guaranteed.
- A financial pathway that could be exploited for self-service fraud.
- A trust measure that reported a passing result regardless of the underlying data — a system that declared itself trustworthy without having earned it.
- A parallel, undocumented authentication path and an administrative bypass that circumvented the controls the platform claimed to enforce.

The enduring lesson of these failures is the reason this Constitution exists at all:
**a system that asserts trustworthiness without proving it is more dangerous than
one that makes no such claim**, because people rely on the assertion. LandVault is
therefore built not upon generic best practice, but upon the specific, confirmed
failures of what came before — each of its non-negotiable rules traceable to a real
finding rather than an abstract ideal.

### II.3 — The Mandate That Follows

From this problem and this lesson, LandVault derives a clear mandate: to make trust
in land information **provable rather than assumed, observable rather than asserted,
and continuously earned rather than granted once**. Four commitments give this
mandate its constitutional force:

1. **Trust must be engineered, not declared.** No capability may report a favourable result that the underlying evidence does not support.
2. **Trust defaults to the cautious position.** Where evidence is absent, incomplete, or unverified, the platform shall reflect that uncertainty honestly, and shall not manufacture confidence it has not established. Missing evidence yields a neutral or low measure of trust, never a passing one.
3. **Trust must be demonstrable.** The trustworthiness of the platform is evidenced by what can be observed to work, not by what is claimed on its behalf.
4. **Trust, once established, must be defended.** Controls that protect the integrity of records may not be silently bypassed, weakened, or duplicated; changes to them proceed only through open, governed decision.

### II.4 — What Is at Stake

The stakes of this mandate are proportionate to what land represents to those it
serves. For a citizen, a trustworthy record may be the difference between a secure
home and dispossession. For a government, it is the foundation of fair taxation,
orderly planning, and public confidence. For a community, it is the faithful
preservation of a shared history. For an investor or lender, it is the basis on
which capital can safely be committed. A platform that handles land information
carelessly does not merely disappoint its users; it can cause irreversible harm to
people who had no choice but to rely on it. LandVault accepts that its
responsibility is measured by this standard.

### II.5 — The Enduring Reasons

Reduced to their essence, the reasons LandVault exists are these, and they are
intended to remain true regardless of how the platform evolves:

- Because trustworthy land information protects people, and untrustworthy land information harms them.
- Because the institutions that administer land deserve tools that strengthen, rather than merely modernise, the integrity of their records.
- Because trust cannot be assumed into existence; it must be engineered, observed, and preserved.
- Because the failures of prior systems demonstrated, concretely, what happens when a platform claims a trust it has not earned.
- Because those who rely on land records — often having no alternative — are entitled to a platform that holds itself accountable to the consequences of its work.

These reasons are the justification for every Article that follows. Where a future
decision would advance them, this Constitution favours it; where a decision would
undermine them, this Constitution stands against it.

---

## Article III — Vision

### III.1 — Vision Statement

LandVault's vision is a world in which land information can be trusted — where the
record of who holds what, and on what evidence, is verifiable, well-governed, and
worthy of the confidence that people, institutions, and communities place in it.

This is the future the platform exists to advance. It is a vision not of a product,
but of a condition: a condition in which the integrity of land information is a
foundation people can build upon rather than a risk they must guard against.

### III.2 — The Future LandVault Seeks

The vision describes a state of affairs that LandVault works to bring closer with
every capability it provides. In that future:

- **Every record carries its provenance.** The origin, history, and supporting evidence of a land record are preserved and visible, so that its trustworthiness can be examined rather than merely presumed.
- **Verification is available to all who rely on the record**, not reserved to those with privileged access, so that trust is shared rather than hoarded.
- **The confidence a record inspires reflects the evidence behind it** — no more and no less — so that certainty is never manufactured and honest uncertainty is never hidden.
- **Legitimate authorities are strengthened, not displaced**, their records made more defensible and their administration more transparent.
- **Communities and citizens can see, and where appropriate contribute to, the record of the land they hold**, so that the register reflects lived reality faithfully.
- **The record endures** across changes of government, technology, and generation, remaining intelligible and trustworthy long after the systems that first captured it have passed.

### III.3 — What the Vision Requires

This vision is deliberately demanding, and the platform accepts what it requires.
It requires that trust be treated as something engineered and evidenced rather than
asserted. It requires that the platform serve the authority of law and the interests
of the vulnerable at the same time, refusing to advance one at the expense of the
other. It requires patience — the willingness to build carefully, verify honestly,
and preserve faithfully, even where speed would be easier. And it requires humility
about the platform's own limits: LandVault pursues a trustworthy record, not the
power to decide whose claim is right.

### III.4 — The Horizon of the Vision

LandVault begins as a land-registry and verification platform serving a defined
jurisdiction and its institutions. Its vision, however, extends to the horizon of
what such a platform can responsibly become: a piece of trusted digital
infrastructure capable, over time, of serving governments, financial institutions,
professional users, communities, and citizens across many contexts.

This wider horizon is an aspiration to be earned, not a claim to be assumed. The
platform advances toward it only as fast as it can preserve trust along the way, and
never by outrunning the discipline that makes it trustworthy. Growth in reach is
legitimate only where it is matched by growth in stewardship.

### III.5 — The Vision as a Standard

This vision is not decoration; it is a standard against which decisions are judged.
A proposed capability, partnership, or change may be measured by a single question:
does it move the platform closer to a world in which land information can be trusted,
or does it trade that trust for some lesser gain? Where a decision advances the
vision, this Constitution commends it. Where a decision would compromise the vision
for convenience, speed, revenue, or reach, this Constitution requires that it be
reconsidered.

The vision endures even as the means of achieving it change. Technologies,
organisations, markets, and features will come and go; the aspiration to make land
information trustworthy remains the fixed point by which the platform sets its course.

---

## Article IV — Mission

### IV.1 — Mission Statement

Where the Vision describes the world LandVault seeks, the Mission describes the work
LandVault does to bring that world about.

LandVault's mission is to preserve, organise, verify, and govern land-related
evidence and registry information so that those who administer, hold, or rely upon
land can do so with justified confidence.

The Mission is the Vision made practical. It is the enduring description of the
platform's work, expressed at a level that will remain true as particular features
change.

### IV.2 — The Work of the Mission

In service of this mission, LandVault undertakes work of the following enduring
kinds. The specific capabilities that realise them will evolve; the categories are
intended to remain stable:

- **To preserve** — to hold land records and their supporting evidence faithfully over time, protecting them against loss, undetected alteration, and decay, and maintaining a defensible account of their history.
- **To organise** — to structure land information so that it is coherent, locatable, and intelligible to those entitled to it, including the spatial relationships that give a parcel its meaning.
- **To verify** — to establish, by observable means, the provenance and integrity of records and the evidence behind them, and to express the resulting confidence honestly rather than presumptively.
- **To attest** — to allow legitimate parties, including communities and authorised professionals, to contribute recognised statements and evidence to the record, with their origin preserved.
- **To govern** — to ensure that access to land information, and changes to it, occur only under proper authority, are subject to isolation between the parties entitled to different records, and leave a durable and auditable trace.
- **To administer responsibly** — to support the lawful operation of land administration, including the identity, authorisation, and provisioning foundations on which trustworthy registry operations depend.

### IV.3 — How the Mission Is Pursued

The mission is defined not only by what LandVault does but by the manner in which it
does it. In pursuing the mission, the platform:

1. **Earns trust before claiming it**, ensuring that every measure of confidence it reports is supported by the evidence beneath it.
2. **Fails safe**, so that absent or unverified information yields caution rather than false assurance.
3. **Protects the boundary between holders**, so that the information of one party is never exposed to another without proper authority.
4. **Preserves history rather than erasing it**, amending the record through governed process and leaving prior states traceable.
5. **Serves authority without assuming it**, strengthening the institutions responsible for land rather than supplanting their judgement.
6. **Acts transparently**, so that those who depend on the platform can understand how their information is preserved, verified, and governed.

### IV.4 — The Boundaries of the Mission

The mission is defined as much by its limits as by its scope. LandVault does not
adjudicate ownership, resolve legal title, or substitute its judgement for that of
the lawful authorities to whom those functions belong. It does not manufacture
certainty that the evidence does not support, and it does not treat the absence of a
dispute as proof of a right. Where the platform records a claim, an attestation, or a
measure of trust, it records what is asserted and what can be observed — not a
verdict upon the truth of the matter. These boundaries are not limitations to be
overcome by future capability; they are permanent features of the platform's
proper role.

### IV.5 — Measuring the Mission

The mission is fulfilled to the extent that land information entrusted to the
platform becomes more trustworthy, more intelligible, and better governed than it
would otherwise be — and to the extent that the confidence people place in that
information is justified. It is not measured by the volume of records held, the
number of users served, or the revenue generated, except insofar as these accompany
a genuine strengthening of trust. A platform that grew large while allowing trust to
decay would be failing its mission, however successful it appeared. LandVault
accepts that its mission is judged by the integrity of what it preserves, not the
scale at which it operates.

---

# Enactment, Completeness & Amendment

## E.1 — Enactment

This document, comprising Phase 0 and Articles I through IV, is ratified as the
**First Edition — Foundation** of the LandVault Constitution (LV-000), and takes
effect as a binding constitutional instrument from 20 July 2026. From this date, the
Constitutional Publishing Rule and the hierarchy it establishes are in force: no
lower-level document — whether an Architecture Decision Record, product,
technical, implementation, or operational document — may contradict this
Constitution, and where a conflict exists this Constitution prevails until the
conflict is reconciled or this Constitution is amended.

## E.2 — On the Completeness of This Edition

This First Edition establishes the Foundation of the Constitution: the reasons the
platform exists, the future it seeks, the work it performs, and the boundaries of its
role. It is complete and binding as to those foundations. It is, by design, the first
of several editions. The further Articles and Parts contemplated by the
constitutional programme — including Purpose, Strategic Promise, Core Values, and
the Product, Engineering, Architectural, Security, Data, AI, Ethical, and Governance
principles, together with the Constitutional Commitments and the Constitutional
Declaration — are not yet enacted. Their absence does not weaken what is ratified
here; it marks the work that remains.

## E.3 — Amendment and Expansion

From ratification, this Constitution is amended and expanded only through governed
process, not through ordinary authorship:

1. **No silent change.** No provision of this Constitution may be altered, repealed, or reinterpreted without a recorded amendment that states what changed and why.
2. **Additions are amendments.** The adoption of any further Article, Part, Commitment, or the Declaration is itself a constitutional amendment, recorded in the Revision History and raising the edition accordingly.
3. **History is preserved.** Amendment amends; it does not erase. Prior ratified text remains traceable, consistent with the versioning standard set out in Phase 0.
4. **Supremacy endures through change.** An amendment takes effect only when ratified by the Governance Authority, and until it does, the existing ratified text remains binding.

## E.4 — Continuity

Where the platform evolves, this Constitution shall provide continuity. Where new
capabilities emerge, it shall provide direction. Where difficult decisions arise, it
shall provide the principles by which those decisions are made. Upon these ratified
foundations, the subsequent editions of the LandVault Constitution shall be built.

*End of First Edition — Foundation. Ratified 20 July 2026.*

---

> ## ✔ RATIFIED — AMENDMENT 1 (In Force)
>
> **Status:** Ratified constitutional amendment — *in force as of 26 July 2026 (edition v1.1).*
> **Adopted:** **Article V — Purpose** into Part I — Foundation, immediately following Article IV.
> **Authority:** Ratified by the LandVault Governance Authority under §E.3. Article V below is binding constitutional text. Its canonical placement is Part I — Foundation, after Article IV.

---

## Article V — Purpose

### V.1 — Statement of Purpose

Where Article II records **why** LandVault exists and Article IV records **what** it
does, this Article records the enduring **ends** it is meant to serve — the purposes
that give the platform's work its meaning and against which its worth is measured.

LandVault's purpose is to make land information a foundation that people and
institutions can safely rely upon: to convert land records from a source of
uncertainty and dispute into a source of confidence, so that the rights, decisions,
and investments that depend on those records rest on ground that can be trusted.

### V.2 — The Purposes LandVault Serves

In fulfilment of this purpose, LandVault exists in order to achieve the following
enduring ends. They are stated as purposes, not features, and are intended to remain
constant as the means of achieving them change:

- **To make trust legible** — so that the confidence a land record deserves can be seen and examined, rather than merely assumed by those who rely on it.
- **To reduce avoidable disputes** — by preserving clear, well-evidenced, and well-governed records that give parties and authorities a reliable basis on which to resolve competing claims.
- **To strengthen legitimate authority** — by equipping the institutions responsible for land administration with records that are more defensible, more transparent, and more resistant to manipulation.
- **To lower the cost of confidence** — so that citizens, communities, professionals, and investors need not each independently and expensively verify what a trustworthy record could establish once.
- **To protect the holder of a rightful claim** — by ensuring that the evidence supporting a legitimate interest in land is preserved faithfully and cannot be quietly erased or overwritten.
- **To preserve memory across time** — so that the record of today remains intelligible, attributable, and trustworthy for those who inherit it tomorrow.

### V.3 — Purpose in Relation to Vision and Mission

These three Articles are deliberately distinct and mutually reinforcing. The **Vision**
(Article III) describes the world LandVault seeks — a world in which land information
can be trusted. The **Mission** (Article IV) describes the work LandVault performs —
to preserve, organise, verify, and govern land information. The **Purpose** (this
Article) describes the ends that work is meant to achieve — the concrete good that
trustworthy land information does for the people and institutions who depend on it.
Vision sets the destination; Mission is the road; Purpose is the reason the journey
is worth making. No one of them may be advanced by abandoning another.

### V.4 — The Discipline of Purpose

Purpose is not only a source of direction; it is a source of restraint. LandVault
declines purposes that lie outside this Article, however available or profitable they
may appear. It does not exist to accumulate land information for its own sake, to
extract value from those it serves at the expense of their trust, to become the
arbiter of disputes it is not entitled to decide, or to convert the records
entrusted to it into an instrument of surveillance, exclusion, or dispossession.
Where a proposed use of the platform cannot be traced to a purpose recognised in this
Article, that absence is itself a reason for caution.

### V.5 — Purpose Fulfilled

LandVault's purpose is fulfilled not when the platform is large, but when the
confidence people place in land information is well-founded — when a citizen can rely
on a record without fear, an authority can defend it without doubt, a community can
recognise its own history within it, and an investor can build upon it without first
having to distrust it. To the degree that the platform brings about these ends, it
serves its purpose; to the degree that it neglects them, no other measure of success
can compensate.

*End of Amendment 1 — ratified and in force (v1.1).*

---

> ## ✔ RATIFIED — AMENDMENT 2 (In Force)
>
> **Status:** Ratified constitutional amendment — *in force as of 26 July 2026 (edition v1.2).*
> **Adopted:** **Article X — Architectural Principles** into Part II — Constitutional Principles, and the first two principles of **Article XV — Governance Principles** (the Trust Neutrality Firewall and Delegated Authority).
> **Occasion:** The strategic reframing of LandVault as a multi-sided trust platform with a surveyor/partner marketplace. These principles govern that programme *before* its bounded contexts are built.
> **Authority:** Ratified by the LandVault Governance Authority under §E.3. The articles below are binding constitutional text.
> **On article numbering:** The Constitution is authored incrementally. Articles VI–IX (Strategic Promise, Core Values, Product, Engineering) and XI–XIV (Security, Data, AI, Ethical) are **reserved** per the master structure and will be authored in future amendments. The numbering gaps are intentional, not omissions. Article XV is in force only in part (XV.1–XV.2); its remaining principles will be added later, consistent with §E.3 (additions are amendments; history is preserved).

---

## Article X — Architectural Principles

### X.1 — LandVault Is a Platform, Not an Aggregate

LandVault is the **platform** — the governed whole under which the system's
capabilities are organised. It is not a single domain object, not an aggregate, and
not a bounded context. The platform is composed of independent bounded contexts, each
owning its own model, and no design shall collapse the platform into one
all-encompassing domain object.

This principle exists to prevent, permanently, the emergence of a "God Aggregate" —
a single object through which all data and behaviour flow. Such an object grows
without bound, forces unrelated concerns to share one consistency boundary, obstructs
independent teams, and ultimately becomes unintelligible. The prohibition is
deliberate and enduring: the convenience of "one central object" is never a
sufficient reason to violate it.

Where a unified, platform-wide view of a parcel or land record is required — for a
portal, a certificate, or a citizen — it shall be provided as a **composed read
model** (a projection assembled from the events of many contexts), which owns no
business rules, and never as a monolithic write aggregate.

### X.2 — Contexts Own Their Aggregates; Integration Occurs by Contract

Each bounded context owns its own aggregates, data, and business rules, and is the
sole authority over the invariants within its boundary. Contexts integrate with one
another only through **explicit, versioned contracts** — published events and defined
interfaces — and never by reaching into another context's model or datastore, and
never by sharing a mutable domain object across boundaries.

A context refers to another context's concept **by identity and contract** — for
example, by a parcel identifier — not by embedding that concept's aggregate within
itself. Consistency **within** an aggregate is immediate and transactional;
consistency **between** contexts is achieved over time through the exchange of events.
No operation shall require a single transaction to span multiple bounded contexts.

### X.3 — One Authorisation Path Across All Surfaces

The platform may present many surfaces — customer, partner, enterprise, government,
programmatic, and others yet to come. Every such surface is a means of presentation
only. All authentication and authorisation for every surface shall resolve through
the **single, unified authorisation path** established by the Identity capability.

No surface, portal, integration, or convenience shall introduce a parallel,
duplicate, or surface-specific authorisation mechanism. The multiplication of
presentation surfaces shall never become the multiplication of security models, for
it was precisely such parallel and undocumented paths that this platform was rebuilt
to eliminate.

### X.4 — Protect the Kernel

The platform's enduring strength lies in its **kernel** — the identity, registry,
spatial, and evidence capabilities that establish and preserve trust. Capabilities
that generate adoption or revenue, however valuable, are **built upon** this kernel
and derive their credibility from it; they do not stand in its place.

No downstream capability — marketplace, enterprise service, or otherwise — shall be
advanced by weakening, bypassing, or neglecting the kernel upon which its own
trustworthiness depends. Where the interests of a business capability and the
integrity of the kernel are in tension, the integrity of the kernel prevails.

---

## Article XV — Governance Principles  *(In force in part — XV.1–XV.2)*

### XV.1 — The Trust Neutrality Firewall

LandVault may operate commercial functions — including the matching of work, the
handling of payments, the holding of funds in escrow, and the facilitation of
transactions between the parties it serves. Where it does so, its **trust functions**
— the preservation of evidence, the verification of records, the maintenance of
audit, and the integrity of any certificate or verification it issues — shall be
**structurally insulated** from those commercial functions.

No commercial incentive shall be permitted to influence what a trust function
reports. In particular: the platform shall not allow the prospect of transaction
revenue to bias any measure of verification, trust, or record integrity; it shall not
represent a commercial outcome as though it were an evidentiary or statutory fact; and
it shall not permit its role as a marketplace operator to compromise its neutrality as
a custodian of evidence. The platform earns from enabling trustworthy transactions —
never from bending the truth of the record.

Where a genuine conflict arises between what is commercially advantageous and what the
evidence supports, the evidence prevails, without exception.

### XV.2 — Delegated Authority

Whatever authority LandVault exercises in respect of land is **derivative and
delegated** — granted by law, by statutory bodies, or by the professional standing of
its licensed participants — and never self-originated. The platform shall not assert,
imply, or commercially market an authority it has not been granted.

Any assurance the platform presents — including any verification, badge, or
certificate — shall be traceable to the specific statutory or professional act from
which it derives, and shall not suggest that LandVault itself has determined
ownership, title, or any matter reserved to a lawful authority. This principle binds
the platform's commercial and marketing conduct as strictly as its technical conduct,
and reaffirms, at the level of the platform's outward representations, the boundary
established in Articles I and IV.

*End of Amendment 2 — ratified and in force (v1.2).*

---

# Consolidated Status & Amendment Log

*This section records the cumulative state of the Constitution. The First-Edition
enactment clause (§E.1–E.4) is preserved verbatim as the historical record of the
20 July 2026 ratification; the amendments below are additions to it, consistent with
§E.3 (history is amended, not erased).*

## Enacted as of Edition v1.7 (Structurally Complete)

- **Part I — Foundation:** Articles I (Preamble), II (Why LandVault Exists), III (Vision), IV (Mission), V (Purpose), VI (Strategic Promise).
- **Part II — Constitutional Principles:** Articles VII (Core Values), VIII (Product), IX (Engineering), X (Architectural), XI (Security), XII (Data), XIII (Artificial Intelligence), XIV (Ethical), XV (Governance — XV.1 Trust Neutrality Firewall, XV.2 Delegated Authority, XV.3 Governed Change, XV.4 Transparency & Auditability, XV.5 Supremacy of the Hierarchy).
- **Part III — Constitutional Governance:** Articles XVI (Decision-Making Framework), XVII (Documentation Governance), XVIII (Architecture Governance), XIX (Security Governance), XX (Product Governance).
- **Part IV — Constitutional Commitments:** to Governments, Communities, Citizens, Professional Users, and Future Generations.
- **Part V — The Constitutional Declaration of LandVault.**

## Reserved — Not Yet Enacted

None. With Amendments 1–7, the constitutional structure mapped for LandVault (Parts I–V) is complete.
Future change proceeds by further amendment under §E.3.

## Amendment Log

| Amendment | Edition | Ratified | Adopted | Status |
|---|---|---|---|---|
| First Edition — Foundation | v1.0 | 20 Jul 2026 | Phase 0 + Articles I–IV; Enactment clause | In force |
| Amendment 1 | v1.1 | 26 Jul 2026 | Article V — Purpose (Part I) | In force |
| Amendment 2 | v1.2 | 26 Jul 2026 | Article X (Architectural); Article XV.1–XV.2 (Governance) | In force |
| Amendment 3 | v1.3 | 26 Jul 2026 | Article VI — Strategic Promise (completes Part I) | In force |
| Amendment 4 | v1.4 | 26 Jul 2026 | Articles VII, VIII, IX (Values, Product, Engineering) | In force |
| Amendment 5 | v1.5 | 26 Jul 2026 | Articles XI, XII, XIII, XIV; XV.3–XV.5 (completes Part II) | In force |
| Amendment 6 | v1.6 | 26 Jul 2026 | Part III — Articles XVI–XX (Constitutional Governance) | In force |
| Amendment 7 | v1.7 | 26 Jul 2026 | Part IV (Commitments); Part V (Declaration) | In force |

*Consolidated to Edition v1.7 — structurally complete (Parts I–V). Ratified by the LandVault Governance Authority.*

---

# Constitutional Catch-Up — Amendments 3–7 (Ratified, In Force)

*The amendments below complete the constitutional structure mapped for LandVault, so that the
Constitution matches the Bible that elaborates it. Each was drafted to the Six Tests of
Constitutional Authorship and drawn from the working principles of LV-002 and the platform's
baselines, and each was ratified by the Governance Authority on 26 July 2026 under §E.3. They are in
force and binding; with their adoption, Parts I–V of the Constitution are structurally complete.*

---

> ## ✔ RATIFIED — AMENDMENT 3 (In Force)
>
> **Status:** Ratified constitutional amendment — *in force as of 26 July 2026.*
> **Proposes:** Adoption of **Article VI — Strategic Promise**, completing **Part I — Foundation**.
> **Effect on ratification:** Raises the edition to **v1.3**; Article VI becomes binding text.

## Article VI — Strategic Promise

### VI.1 — The Promise

LandVault promises to build and steward a trusted digital infrastructure for land — one whose worth
is measured by the confidence it earns and preserves, and not by the scale at which it operates.
This is a strategic promise: a commitment that binds not a plan or a version of the product, but the
enduring evolution of the platform.

### VI.2 — To Whom the Promise Is Made

The promise is made to those the platform serves — governments, communities, citizens, professional
users, and financial institutions — to those who build and steward the platform, and to the future
generations who will inherit the record. It commits the platform to advance their interest in
trustworthy land information above its own convenience, revenue, or reach.

### VI.3 — The Content of the Promise

The Strategic Promise comprises enduring commitments: to protect the trusted kernel — identity,
registry, spatial, and evidence — before any capability built upon it; to earn the platform's wider
role rather than assert it, matching every gain in reach with a corresponding gain in stewardship;
to build and maintain the trust network — the standards, workflows, evidence, and audit — that makes
participation worthwhile for every party; to keep the platform's trust functions neutral and its
authority delegated; and to grow only where growth accompanies a genuine strengthening of trust.

### VI.4 — The Promise as a Constraint

The Strategic Promise binds strategy as a constraint, not merely as an aspiration. A strategic choice
that would breach it — that would sacrifice the kernel, outrun the trust the platform can preserve,
bias its neutrality, or claim an authority it has not been granted — is foreclosed regardless of its
commercial appeal. Where strategy and promise conflict, the promise prevails.

*End of Amendment 3 — ratified and in force.*

---

> ## ✔ RATIFIED — AMENDMENT 4 (In Force)
>
> **Status:** Ratified constitutional amendment — *in force as of 26 July 2026.*
> **Proposes:** Adoption of **Article VII — Core Values**, **Article VIII — Product Principles**, and **Article IX — Engineering Principles** into **Part II — Constitutional Principles**.
> **Effect on ratification:** Raises the edition to **v1.4**; these Articles become binding text, and the corresponding working principles of LV-002 are re-designated constitutional.

## Article VII — Core Values

### VII.1 — The Values

The platform holds the following values as the enduring character it intends to bring to every
decision:

- **Trust before all else** — every capability must strengthen, and none may knowingly weaken, the trustworthiness of land information.
- **Evidence over assertion** — the platform reports what can be observed and supported, never what is merely claimed, and never hides honest uncertainty.
- **Authority served, not assumed** — the platform strengthens legitimate institutions and never asserts an authority it has not been granted.
- **Protection of the vulnerable** — the platform must never become an instrument by which the powerful dispossess the powerless of their rightful claims.
- **Candour** — the platform is honest about what it has built and what it has not, distinguishing capability that is live from capability that is merely intended.
- **Stewardship and endurance** — the platform preserves the record and its history faithfully, and remains trustworthy across changes of technology, organisation, and generation.
- **Governed change** — the platform changes through recorded, reasoned, and reversible decisions; history is amended, never quietly rewritten.

### VII.2 — The Force of the Values

These values are the disposition from which the platform's more specific principles follow. Where a
decision cannot be reconciled with them, it is not made on the strength of its other merits; it is
reconsidered.

## Article VIII — Product Principles

### VIII.1 — Capability Earns Its Place

A capability earns its place in the platform only by strengthening trust in land information;
utility, demand, or revenue alone do not justify it. A proposed capability that cannot be traced to a
purpose recognised in Article V is, by that absence, a matter for caution.

### VIII.2 — Measured by Integrity

The product is measured by the integrity of what it preserves and the justified confidence of those
who rely on it — not by the volume of records, the number of users, or the revenue generated, except
insofar as these accompany a genuine strengthening of trust (Article IV.5).

### VIII.3 — Candour in Product

The platform does not present planned capability as delivered, nor scaffolded capability as live. The
distinction between what exists and what is intended is maintained honestly in everything the product
represents.

## Article IX — Engineering Principles

### IX.1 — Principles Grounded in Confirmed Failure

The platform is engineered according to the following principles, each of which exists because a
specific, confirmed failure in a prior build made it necessary, and none of which is waivable:

- Authorisation is defined together with the data it protects, in the same change, and never added afterward.
- Security configuration fails safe: a missing required control halts the system rather than defaulting to a permissive state.
- Automated assessment fails safe: absent or insufficient evidence yields a low or explicitly insufficient result, never a passing one.
- Every participant and every surface resolves through a single authorisation path; no parallel, duplicate, or bypass route exists.
- Dependencies are admitted only with justification and pinned versions.
- Schema changes are reversible and ship with their matching authorisation.
- No capability is complete until its tests have actually been run and observed to pass.
- Change is committed with discipline — bounded, documented, and explained — so that the platform's history remains legible.

*End of Amendment 4 — ratified and in force.*

---

> ## ✔ RATIFIED — AMENDMENT 5 (In Force)
>
> **Status:** Ratified constitutional amendment — *in force as of 26 July 2026.*
> **Proposes:** Adoption of **Article XI — Security Principles**, **Article XII — Data Principles**, **Article XIII — Artificial Intelligence Principles**, **Article XIV — Ethical Principles**, and the remaining principles of **Article XV — Governance Principles (XV.3–XV.5)**, completing **Part II — Constitutional Principles**.
> **Effect on ratification:** Raises the edition to **v1.5**; these Articles become binding text.

## Article XI — Security Principles

Security is a property of the platform's construction, not an inspection performed after the fact.
Access is denied by default and granted only by explicit, auditable policy. There is one
authorisation path and no route around it (reaffirming Articles X.3 and IX). Secrets are protected
and never exposed, and the absence of a required security control halts the system rather than being
tolerated. Security is evidenced by observation — tests that run and pass — rather than asserted by
review alone.

## Article XII — Data Principles

Evidence is preserved with integrity: once recorded it is sealed against undetected alteration, its
provenance and chain of custody are maintained, and its history is retained rather than overwritten.
Records are isolated so that the information of one party is never exposed to another without proper
authority. Personal information is protected in proportion to its sensitivity. Any measure of trust
rests on real, observable data; a measure built on absent or fabricated data is a defect, not a
result. History is amended through governed process and never erased.

## Article XIII — Artificial Intelligence Principles

Where the platform employs artificial intelligence, it does so in an advisory capacity only.
Automated analysis may assist, surface, and explain; it may not determine rights, title, or any
matter reserved to a lawful authority, and it may not be the sole basis of a consequential decision.
Automated outputs are held to a quality threshold before use, are explainable rather than opaque, and
fail safe: where the basis for a judgement is insufficient, the system declines to assert one.
Artificial intelligence strengthens the platform's trust functions; it never substitutes for the
evidence or the authority behind them.

## Article XIV — Ethical Principles

The platform holds itself to ethical limits that bind its technical and its commercial conduct alike.
It protects the vulnerable and refuses to become an instrument of dispossession. It does not exploit
those it serves, and it eschews manipulative or persuasive design. It does not convert the records
entrusted to it into instruments of surveillance or exclusion. It serves all its users with dignity
and inclusion, regardless of device, connection, literacy, or ability. And it is honest — candid
about its state and its limitations — because to overstate its trustworthiness would itself be an
ethical failure.

## Article XV — Governance Principles (continued)

### XV.3 — Governed Change

The platform changes only through recorded, reasoned, and reversible decisions. No provision, record,
or control is altered without a governed change that states what changed and why; history is
preserved rather than rewritten (consistent with §E.3).

### XV.4 — Transparency and Auditability

Consequential actions are attributable and auditable, and those who rely on the platform are entitled
to understand how their information is preserved, verified, and governed. The platform is built to be
examined, not merely trusted.

### XV.5 — Supremacy of the Hierarchy

No lower-level instrument may contradict a higher-level one; where a conflict exists, the higher
prevails until the lower is reconciled or the higher is amended through governed process. This
principle restates, at the level of governance, the Constitutional Publishing Rule.

*End of Amendment 5 — ratified and in force.*

---

> ## ✔ RATIFIED — AMENDMENT 6 (In Force)
>
> **Status:** Ratified constitutional amendment — *in force as of 26 July 2026.*
> **Proposes:** Adoption of **Part III — Constitutional Governance**, comprising **Article XVI — Decision-Making Framework**, **Article XVII — Documentation Governance**, **Article XVIII — Architecture Governance**, **Article XIX — Security Governance**, and **Article XX — Product Governance**.
> **Effect on ratification:** Raises the edition to **v1.6**; Part III becomes binding text.

# Part III — Constitutional Governance

## Article XVI — Decision-Making Framework

### XVI.1 — Two Modes of Decision

Decisions proceed in one of two modes. In-scope, tested, reversible changes that violate no principle
of this Constitution proceed autonomously. Decisions that change schema, introduce dependencies,
touch authorisation or payments, delete data, bear on legal-adjacent matters, are irreversible in
production, or expand agreed scope require explicit human authorisation before they proceed.

### XVI.2 — Assessment Against Gates

Every significant decision is assessed against the platform's standing questions and must pass its
quality and phase gates. A decision is not made on the strength of expedience where it cannot pass.

### XVI.3 — Recorded Before Acted Upon

Architectural and constitutional decisions are recorded — as an Architecture Decision Record or a
constitutional amendment — before they are acted upon, so that the reason for a decision survives the
decision.

### XVI.4 — Resolution of Conflict

Where principles conflict in a specific case, they are resolved in the order this Constitution
establishes: the preservation of trust and the integrity of the record first; the authority of law
and legitimate institutions next; the protection of those who rely on the platform, particularly the
vulnerable, above convenience, speed, reach, or revenue.

## Article XVII — Documentation Governance

The platform is governed by a single, ordered hierarchy of documents (§E.1 and the Constitutional
Publishing Rule), in which no lower document contradicts a higher. Every governed document carries the
publication-standard control fields, is versioned as software is versioned, and preserves its history
append-only. Amendment proceeds only through the governed process of §E.3. Subordinate documentation
is maintained in reconciliation with the Constitution above it; when the Constitution is amended, the
documents beneath it are brought into conformity.

## Article XVIII — Architecture Governance

Significant architectural decisions are governed through Architecture Decision Records, each
referencing the decisions it builds upon and none contradicting this Constitution. Changes to frozen
work proceed only through such records. The platform-as-platform-not-aggregate and
integration-by-contract requirements of Article X are enforced through this governance, and no new
production phase begins until its mandatory architecture review has passed.

## Article XIX — Security Governance

Security is governed continuously. Each phase gate includes a mandatory security review, and no new
production phase begins while a critical or high-severity finding is open. The platform's non-waivable
security blockers are enforced without exception. Security incidents are recorded and their lessons
fed back through governed change, and the platform's construction is assessed against recognised
standards on a standing basis.

## Article XX — Product Governance

Product scope is governed with discipline. The distinction between the minimum product and deferred
capability is maintained, and deferred scope enters only through recorded sign-off (a Ratification-Log
entry or an ADR amendment). Completion is governed by the tiered Definition of Done. The product is
measured by the integrity of what it preserves rather than by its scale (Articles IV.5, VIII), and the
Trust Neutrality Firewall (Article XV.1) is maintained as a standing product-governance control.

*End of Amendment 6 — ratified and in force.*

---

> ## ✔ RATIFIED — AMENDMENT 7 (In Force)
>
> **Status:** Ratified constitutional amendment — *in force as of 26 July 2026.*
> **Proposes:** Adoption of **Part IV — Constitutional Commitments** and **Part V — The Constitutional Declaration of LandVault**, completing the constitutional structure.
> **Effect on ratification:** Raises the edition to **v1.7**; the Constitution's mapped structure is complete.

# Part IV — Constitutional Commitments

The platform makes the following enduring commitments to those it serves. They are the human meaning
of the principles above.

**To Governments.** LandVault commits to support lawful land administration with a disciplined,
auditable, and sovereign-respecting foundation; to strengthen the institutions responsible for land
rather than to displace them; and to assert no authority it has not been granted.

**To Communities.** LandVault commits to record collective histories, boundaries, and customary
arrangements faithfully; to preserve them against loss; and to allow communities and their legitimate
authorities to contribute recognised attestation to the record.

**To Citizens.** LandVault commits to protect the security of a rightful claim — often the security of
a home, a livelihood, or a legacy; to remain affordable, intelligible, and honest; and never to
become an instrument of a citizen's dispossession.

**To Professional Users.** LandVault commits to treat licensed surveyors, firms, and other
professionals as partners; to provide standardised, fair, and reliable workflows; and to make their
professional standing legible without substituting for it.

**To Future Generations.** LandVault commits to preserve the record, and the trust placed in it,
across changes of technology, organisation, and generation — so that those who inherit the record
inherit something worthy of their confidence.

# Part V — The Constitutional Declaration of LandVault

We establish LandVault to preserve trust in land information — not merely to digitise land records.

We hold that the value of a land record lies in the fact that it can be trusted, and that trust must
be engineered, demonstrated, and preserved, never assumed. We commit to serve the authority of law
and the interests of those who rely on land information, and above all to protect those least able to
protect their own claims. We commit to preserve evidence faithfully, to keep our trust functions
neutral, to claim no authority we have not been granted, and to change only through governed,
recorded, and reversible decision.

We accept that our worth is measured by the integrity of what we preserve and the justified confidence
of those we serve — not by our scale. Upon this Constitution, and the principles, governance, and
commitments it establishes, the LandVault platform and every document beneath it are founded, and to
it every future decision is answerable.

*End of Amendment 7 — ratified and in force.*

*End of Constitutional Catch-Up amendments (Amendments 3–7, ratified and in force). With these,
Parts I–V of the LandVault Constitution are structurally complete.*

---
