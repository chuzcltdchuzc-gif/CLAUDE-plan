# The Official LandVault Bible™

## Volume LV-005 — Product Requirements Document (PRD)

*A subordinate volume of The Official LandVault Bible™, governed by LV-000 — The LandVault Constitution.*

---

## Document Control

| Field | Entry |
|---|---|
| **Document ID** | LV-005 |
| **Title** | Product Requirements Document (PRD) |
| **Library** | The Official LandVault Bible™ |
| **Tier** | Bible (subordinate to the Constitution) |
| **Version** | v0.1 (Draft for Review) |
| **Status** | Draft — Under Authorship |
| **Classification** | Public (Governance) |
| **Owner** | Office of the LandVault Constitution (Governance Authority) |
| **Governed By** | LV-000 (v1.7); consistent with LV-001, LV-002, LV-003, LV-004 |
| **Governs** | The Technical Requirements Document (LV-006) and all implementation specifications |
| **Source Baselines** | Development-Plan repository — Definition of Done (Tiers 1–3), Engineering Rules, Phase Gates, Rebuild Plan (13 bounded contexts, M0–M7) |
| **Review Cycle** | Per milestone, or upon a scope change recorded as an ADR/Ratification entry |
| **Language** | English (UK) |

*Subordinate to LV-000. Requirements are stated so as to be testable. The non-negotiable
constraints in §7 are not requirements that may be traded against others; they are gating
conditions derived from the platform's engineering rules and Definition of Done, and no
requirement in this document may be satisfied in a way that violates them.*

---

## 1. Purpose and Scope

This document specifies **what** the LandVault product must do, at the level of testable
requirements, so that the Technical Requirements Document (LV-006) can specify **how**. It
defines the users, the scope of the first releasable product, the functional and
non-functional requirements, the non-negotiable constraints, and the acceptance model. It
is grounded in the platform's Definition of Done and Rebuild Plan, and it distinguishes
rigorously between requirements in scope for the initial pilot-ready product and
capabilities deliberately deferred.

Requirements are identified as **FR-n** (functional) and **NFR-n** (non-functional) for
traceability. Each requirement is expressed so that its satisfaction can be observed by a
passing test, consistent with the platform's "observe, then mark complete" rule.

## 2. Product Summary

The initial LandVault product enables a user to establish a verified identity, to register
or locate a parcel, to have that parcel's location and boundaries validated, to attach and
seal supporting evidence, to request professional verification, to pay for it, to track its
status, and to hold the resulting records in a secure vault — through a web and mobile
interface, under a single governed authorisation model. This is the minimum product that
delivers the platform's purpose in a usable form: it lets a party convert an informal or
undocumented land interest into a trustworthy, evidenced, verifiable record.

## 3. Users and Access Surfaces

The product serves four classes of participant through four presentation surfaces, all
resolving through the single authorisation path of the Identity capability.

- **Customers** (citizens, households, and the diaspora) — via the Customer Portal.
- **Partners** (licensed surveyors and survey firms) — via the Partner Portal.
- **Enterprises** (banks, mortgage providers, law firms, developers, insurers) — via the Enterprise Portal.
- **Government** (surveyor-general offices, land registries, planning and compliance authorities) — via the Government Portal.

Firms are represented as organisations under which individual professionals act, using the
frozen B2 Organization foundation, so that work may be dispatched to a firm and fulfilled
by its members.

## 4. Scope

### 4.1 In Scope — Initial Pilot-Ready Product

Drawn from the Definition of Done (Tier 3), the initial product must allow users to:
register and authenticate; search for and view properties/parcels; request verification;
upload and seal supporting documents; make payment; receive and track verification status;
access a secure vault of their records; and use both desktop and mobile interfaces.

### 4.2 Deferred — Post-MVP (Explicit Sign-Off Required)

The following are deliberately **out of scope** for the initial product and require
explicit sign-off, recorded as a Ratification-Log entry or ADR amendment, before they are
built: the Knowledge Graph (multi-hop relationship queries); the full Trust Engine with
explainable per-parcel scoring across multiple signals; and the Inheritance & Customary-Law
capability. Marketplace transaction features beyond basic survey assignment and payment
(open discovery, escrow, ratings, dispute resolution) are strategic direction (LV-003) and
are likewise post-MVP.

## 5. Functional Requirements

### 5.1 Identity & Access (Context: Identity — frozen B1/B2)

- **FR-1.** Every user shall register and authenticate through the single platform identity provider, with role and organisation scope assigned; no alternative or parallel authentication path shall exist.
- **FR-2.** Access to every resource shall be decided by the central authorisation engine (PDP/PEP); no resource shall be reachable except through it.
- **FR-3.** Organisations (firms, banks, agencies) shall be representable, with delegated administration allowing an organisation to manage its own members within time-bounded, revocable grants.
- **FR-4.** Every consequential action shall produce an immutable audit entry attributable to an authenticated actor.

*Acceptance:* authorisation is verified through the PDP/PEP; a request bypassing it is
denied; delegation can be granted and immediately revoked; audit entries are produced and
tamper-evident.

### 5.2 Registry (Context: Registry — canonical parcel record)

- **FR-5.** A parcel shall be registrable as a canonical record with a unique parcel identifier; duplicate parcel numbers within a tenant shall be prevented.
- **FR-6.** A parcel's ownership and status history shall be retained; an archived parcel shall be immutable.
- **FR-7.** Users shall search for and view parcels for which they are authorised, with results scoped by their identity and organisation.

*Acceptance:* a duplicate parcel number is rejected; an archived parcel cannot be mutated;
search returns only authorised records.

### 5.3 Spatial Validation (Context: Spatial Intelligence)

- **FR-8.** Coordinates and boundary polygons shall be validated for geometric correctness and a defined coordinate reference system before acceptance.
- **FR-9.** Overlaps and conflicts between a submitted boundary and existing parcels shall be detected and surfaced.
- **FR-10.** Geometry shall be versioned and append-only, with exactly one active version and prior versions superseded rather than deleted.

*Acceptance:* an invalid polygon or missing CRS is rejected; an overlapping boundary is
flagged; superseding a geometry preserves the prior version.

### 5.4 Evidence (Context: Evidence)

- **FR-11.** A user shall upload supporting documents, which shall be cryptographically hashed on receipt.
- **FR-12.** Sealed evidence shall be immutable (write-once) with a preserved chain of custody and timestamp; it shall not be alterable after sealing.
- **FR-13.** The integrity of stored evidence shall be verifiable at any later time.

*Acceptance:* an uploaded document is hashed and sealed; a later integrity check confirms
it is unchanged; an attempt to alter sealed evidence is prevented and detectable.

### 5.5 Survey & Verification Request (Contexts: Survey, Workflow)

- **FR-14.** A user shall request verification of a parcel; the request shall progress through a defined state machine with observable status.
- **FR-15.** A verification shall be assignable to a licensed surveyor or firm, with licensing checked at assignment.
- **FR-16.** A surveyor/firm shall submit survey plans and evidence against an assignment; submissions shall be recorded in the Evidence context with provenance preserved.
- **FR-17.** The requesting user shall track the status of a request through to completion.

*Acceptance:* a request moves through its defined states; assignment to an unlicensed party
is prevented; submitted plans are sealed as evidence; status is visible to the requester.

### 5.6 Trust Indication (Context: Trust Engine — MVP-limited, fail-safe)

- **FR-18.** Where the platform presents any indication of confidence in a record, that indication shall be derived only from real, observable signals.
- **FR-19.** Where evidence is absent or insufficient, the platform shall return a low or explicit "insufficient data" result, and shall never return a passing or favourable score on absent data.
- **FR-20.** Full explainable, multi-signal per-parcel scoring is post-MVP; the initial product shall not present a composite trust score it cannot substantiate.

*Acceptance:* a zero-data or missing-data input yields a low or `INSUFFICIENT_DATA` result
in an asserting test; no code path returns a passing score without supporting evidence.

### 5.7 Payments (Context: Economic/Billing)

- **FR-21.** A user shall pay for verification through the platform, with payment recorded in an atomic ledger.
- **FR-22.** Financial operations shall be atomic and reconcilable; no self-service path shall permit a user to alter balances outside authorised, audited transactions.
- **FR-23.** Payment state shall integrate with verification workflow so that status reflects payment where required.

*Acceptance:* a payment is recorded atomically and reconciles; no unauthorised balance
change is possible; payment and workflow states remain consistent.

### 5.8 Secure Vault & Interfaces

- **FR-24.** A user shall access a secure vault containing their records, evidence, and outcomes, scoped to their authorised access.
- **FR-25.** The product shall be usable through both desktop and mobile web interfaces, presenting the same governed capabilities through the appropriate portal.

*Acceptance:* vault contents are correctly scoped to the authenticated user; core journeys
complete on both desktop and mobile.

## 6. Non-Functional Requirements

- **NFR-1 (Security).** The product shall satisfy OWASP-aligned security expectations; every entity shall ship with an authorisation/row-level-security policy in the same change that introduces it.
- **NFR-2 (Fail-safe configuration).** A missing required security configuration shall halt startup rather than default to a permissive state.
- **NFR-3 (Performance).** Interactive operations shall meet defined response-time targets; queries shall be optimised and free of N+1 patterns.
- **NFR-4 (Scalability).** The architecture shall be assessed against defined load tiers (on the order of 10,000, 100,000, and 1,000,000 users) and shall scale by context without a central bottleneck.
- **NFR-5 (Availability & Recovery).** The system shall be deployable to staging, roll back within a defined short window, and have backup and recovery procedures that are tested rather than assumed.
- **NFR-6 (Observability).** The system shall provide the logging, audit, and monitoring necessary to observe its behaviour and to investigate incidents.
- **NFR-7 (Data protection).** Personal information shall be protected in proportion to its sensitivity, with particular care where inheritance or family data is involved.
- **NFR-8 (Accessibility & Clarity).** Interfaces shall be intelligible to non-expert citizens as well as professionals, consistent with the platform's clarity standard.

## 7. Non-Negotiable Constraints (Gating)

The following are binding gating conditions, derived from the platform's engineering rules
and Definition of Done. No requirement above may be satisfied in a manner that violates any
of them, and no feature may be marked complete while any is unmet:

1. No entity or table without a row-level-security/authorisation policy in the same change.
2. No permissive security defaults; missing security configuration fails safe.
3. No parallel or duplicate authorisation path outside the central PDP/PEP.
4. No scoring or validation function that returns a passing result on zero or missing data.
5. No feature marked complete without an observed, passing test.
6. New dependencies only with justification and pinned versions; schema changes reversible and shipped with matching authorisation.
7. Change committed with discipline — one bounded context per change, Definition-of-Done checklist satisfied, and the rationale recorded.

## 8. Acceptance and Definition of Done

Acceptance follows the platform's three-tier Definition of Done. A **feature** is done when
its functional and non-functional requirements are met, its authorisation is verified
through the PDP/PEP, its tests (unit, integration, end-to-end) pass and have been observed
to pass, and its documentation is updated. A **bounded context** is done when all its
features meet Tier 1, cross-context integration is tested, the phase gate passes, and a
Definition-of-Done review is logged before merge. The **product** is done, for pilot
purposes, when the in-scope journeys of §4.1 are demonstrably complete end to end, and the
deferred items of §4.2 remain explicitly out of scope pending sign-off.

## 9. Release Milestones

The product is delivered against the platform's milestone roadmap — labelled M0 through M7 in
the Rebuild Plan, and including intermediate milestones (for example M2.4 and M2.5) so that the
narrative steps below do not each correspond to a whole-numbered milestone — each milestone gated by
the quality model: the platform is brought online with authentication and continuous
integration; a core registry with real spatial validation follows; then an evidence-backed
registry with enforced legal hold; a live surveyor network with archive import; trust
intelligence on real signals with duplicate detection; community trust as a further signal;
inheritance and customary-law handling with protected personal data; real billing with
atomic wallets and revenue sharing; the knowledge graph and fraud detection; and finally
operational hardening ahead of pilot launch. No milestone begins until the prior milestone
has passed its mandatory gates.

## 10. Assumptions, Dependencies and Risks

The product assumes the availability of the frozen identity and organisation foundations
(B1/B2), of payment integration, and of licensed professionals to fulfil verification. It
depends on integration with statutory land authorities for the fullest expression of its
value, and on those authorities retaining the authority the platform serves. Principal
risks include the difficulty and contestability of source land data, the decentralisation
of authority across many jurisdictions, and the trust deficit the platform must overcome by
earning credibility rather than assuming it. These risks are addressed by the platform's
fail-safe posture, its integration-led strategy, and its candour about maturity.

## 11. Traceability

Every requirement in this document is answerable to the Constitution. The identity,
authorisation, and audit requirements express the single-authorisation-path and
governed-access principles (Article X.3; Articles I and IV). The evidence and registry
requirements express the mission's preservation and verification duties (Article IV) and
the fail-safe treatment of trust (Article II.3). The payments and neutrality requirements
express the Trust Neutrality Firewall (Article XV.1). The architectural constraints express
Platform-not-Aggregate and integration-by-contract (Article X). Where this document and the
Constitution could be read to differ, the Constitution prevails.

---

*End of LV-005 — Product Requirements Document (Draft v0.1). Governed by LV-000 — The LandVault Constitution (v1.7). Submitted for review.*
