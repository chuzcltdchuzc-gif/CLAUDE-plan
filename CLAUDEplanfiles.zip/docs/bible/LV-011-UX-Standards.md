# The Official LandVault Bible™

## Volume LV-011 — UX Standards

*A subordinate volume of The Official LandVault Bible™, governed by LV-000 — The LandVault Constitution.*

---

## Document Control

| Field | Entry |
|---|---|
| **Document ID** | LV-011 |
| **Title** | UX Standards |
| **Library** | The Official LandVault Bible™ |
| **Tier** | Bible (subordinate to the Constitution) |
| **Version** | v0.1 (Draft for Review) |
| **Status** | Draft — Under Authorship |
| **Classification** | Public (Governance) |
| **Owner** | Office of the LandVault Constitution (Governance Authority) |
| **Governed By** | LV-000 (v1.7); LV-005 (PRD); LV-010 (Design System) |
| **Governs** | Interaction design and journey implementation across all portals |
| **Source Baselines** | Development-Plan repository — DoD Tier-3 MVP journeys; four portals |
| **Review Cycle** | Per release, or upon a change to a governed journey |
| **Language** | English (UK) |

*Subordinate to LV-000, LV-005, and LV-010. These standards apply the design system to the
platform's journeys; where a journey and a requirement in the PRD could be read to differ, the
PRD prevails, and above it the Constitution.*

---

## 1. Purpose and Scope

This volume defines how users experience LandVault: the standards for its journeys,
interactions, feedback, and error handling, so that the platform is not only correct and secure
but usable, honest, and humane. It applies the foundations of LV-010 to the requirements of
LV-005, and it holds every journey to the platform's clarity and candour values.

## 2. UX Principles

**Clarity of task.** At every step, a user should understand where they are, what is being
asked, and what will happen next. Complexity is progressively disclosed, never dumped.

**Honesty of state.** The interface always tells the truth about status and confidence,
including uncertainty. A pending verification looks pending; insufficient evidence looks
insufficient; nothing is dressed up as more settled than it is.

**Rigour without friction.** The platform's necessary rigour — authorisation, evidence,
verification — is expressed with the least friction consistent with integrity. Rigour is never
theatre, and friction is never gratuitous.

**Transparency of process.** Users can see how a request progresses, who is acting on it, and
on what evidence, so that trust is earned through visibility rather than asked for.

**Respect and inclusion.** The experience assumes a wide range of users and never talks down to
them, exploits them, or excludes them.

## 3. Core User Journeys

The following journeys, drawn from the PRD, are the platform's primary experiences. Each is
designed to be completable on desktop and mobile, through the appropriate portal, under the
single authorisation path.

- **Establish identity.** A user registers and authenticates, with clear explanation of why identity is required and how it is protected; organisations onboard their members through delegated administration.
- **Find or register a parcel.** A user searches for a parcel or registers a new one, receiving clear feedback on uniqueness, scope, and what information is needed.
- **Validate boundaries.** Spatial submission gives immediate, understandable feedback on validity and on any detected overlap or conflict.
- **Attach evidence.** A user uploads supporting documents and sees them sealed, with a clear indication that the evidence is now preserved and tamper-evident.
- **Request verification.** A user requests professional verification, understands what it involves and costs, and is guided through assignment to a licensed surveyor or firm.
- **Pay.** Payment is clear, itemised, and separated visually from evidentiary displays; the user understands what they are paying for and its status.
- **Track status.** The user follows a request through its defined states to completion, always able to see the current state and what is awaited.
- **Access the vault.** The user reaches their records, evidence, and outcomes in a secure vault, scoped to their authorised access.

## 4. Interaction and Validation Standards

Forms request only what is needed, in a logical order, with clear labels and helpful, specific
inline validation that prevents errors before submission rather than only reporting them
afterward. Destructive or consequential actions — anything that deletes data, moves money,
changes authority, or touches legal-adjacent matters — require clear, explicit confirmation and,
where appropriate, are reversible or carry a recovery path; these correspond to the actions the
platform gates for human decision. Progressive disclosure keeps complex tasks approachable.
Every interactive element is keyboard-operable and accessible, per LV-010.

## 5. Status, Feedback and the Communication of Uncertainty

Feedback is immediate, specific, and honest. Every action produces a clear response; every
long-running process shows its state and what is awaited. Crucially, **uncertainty is
communicated, not hidden.** Where the platform's evidence is insufficient to assert confidence,
the experience says so in plain terms and with the distinct insufficient-data treatment of the
design system — never a reassuring signal it has not earned. A disputed or contested record is
shown as such. This standard is the user-facing expression of the platform's fail-safe rule: the
interface would rather admit "we cannot yet confirm this" than imply a confidence the evidence
does not support.

## 6. Trust and Evidence Experience

Because the platform's product is trust, its handling of evidence and authority in the interface
is held to a particular standard. A record's provenance — its source, its supporting evidence,
its chain of custody, and the authority behind any assurance — is available to the user, so that
they can examine trust rather than merely receive it. Any verification, badge, or certificate is
presented with its basis, and never in a way that implies LandVault itself determined ownership
or title; the interface attributes authority to the statutory or professional act from which it
derives (Article XV.2). Commercial elements are kept clearly distinct from evidentiary ones, so a
user never mistakes a paid outcome for an evidentiary fact (Article XV.1).

## 7. Accessibility and Inclusion in Practice

Journeys are designed for the platform's real users: on modest devices and constrained
connections, for a range of literacy levels, and for assisted use. Language is plain; critical
steps do not depend on fine motor precision, perfect eyesight, or a fast connection; and, where
localisation is available, users can proceed in a language and format they understand. The
experience assumes that a first-time citizen user and an expert official are both entitled to
succeed.

## 8. Error Prevention and Recovery

The platform prevents errors where it can and recovers gracefully where it cannot. Inputs are
validated early and specifically; risky actions are confirmed and, where possible, reversible;
and when something fails, the user receives a clear, non-technical explanation and a path
forward rather than a dead end. Security and consequential actions fail safe in the experience as
they do in the system: when in doubt, the interface protects the user and the record rather than
proceeding.

## 9. Consistency and Portal Adaptation

All journeys draw on the same design system and interaction standards, so that patterns learned in
one place transfer to another. Portals adapt emphasis and density to their audience — a government
official and a first-time citizen have different needs — but never diverge in integrity, honesty,
or accessibility. Consistency is a trust signal in itself: a coherent platform is easier to
believe than a fragmented one.

## 10. Measuring the Experience

The experience is measured by outcomes that matter: whether users can complete the journeys they
came for, whether they correctly understand the status and confidence of their records, and
whether they can do so across devices, connections, and abilities. It is **not** measured by
engagement for its own sake, and the platform does not optimise for time-on-task, compulsive
return, or other vanity or attention metrics, which would conflict with its restraint and its
refusal of persuasive design. Comprehension and successful, honest task completion are the
measures that count.

## 11. Governance and Traceability

These standards are governed with the rest of the Bible: significant UX decisions are recorded,
and changes proceed through governed process. Traceability is direct — the honest-status and
uncertainty standards implement the fail-safe mandate (Article II.3) and the candour value; the
consequential-action confirmations implement the platform's human-decision gates; the evidence and
authority experience implements Articles XV.1 and XV.2; and the accessibility standards implement
the duty to serve all who rely on the platform (Article I.3). Where these standards and a higher
document could be read to differ, the higher document prevails.

---

*End of LV-011 — UX Standards (Draft v0.1). Governed by LV-000 (v1.7), LV-005, and LV-010. Submitted for review.*
