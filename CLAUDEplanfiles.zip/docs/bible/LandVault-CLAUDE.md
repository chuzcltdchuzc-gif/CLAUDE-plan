# CLAUDE.md — LandVault Build-Time System Rules

> **What this file is.** The strict operating ruleset for any agent or engineer building
> LandVault (human or Claude Code). It is the machine-actionable distillation of the
> governing documents. It adds no authority of its own: it restates, in imperative form,
> what those documents already require.
>
> **Position in the hierarchy (a lower document may never contradict a higher one):**
>
> `LV-000 Constitution → The Bible (LV-001…) → ADRs → Product Docs → Technical Docs → THIS FILE → Implementation → Operations`
>
> If this file conflicts with anything above it, **the higher document wins** and this file
> is corrected by a recorded change. When unsure, stop and consult LV-000, LV-005 (PRD),
> LV-006 (TRD), LV-007 (Security), and the relevant ADR.

---

## 0. Read Before You Build

Before writing code for any task, confirm you have read and are acting consistently with:
`LV-000` (Constitution, esp. Articles I, IV, X, XV), `LV-005` (PRD — the requirement you are
satisfying), `LV-006` (TRD — the architecture), `LV-007` (Security), and the governing `ADR`
for the area you are touching (e.g. **ADR-004** for authorisation).

---

## 1. Prime Directive

**Preserve trust in land information. Do not merely digitise it.**

- LandVault **verifies and preserves** land evidence. It **does NOT adjudicate ownership or title.** Never write code, copy, or output that claims LandVault determines who owns land.
- Never present a commercial outcome as an evidentiary or statutory fact.
- Trust is **earned and observed**, never asserted. If you cannot prove it with a passing test, it is not done.

---

## 2. The Non-Negotiable Rules (MUST / MUST NOT)

Each rule exists because a real, confirmed exploit path required it. None is waivable.

1. **Authorization in the same commit.** MUST NOT create any entity/table without its RLS or PDP/PEP authorization policy **in the same commit**.
2. **Secure-by-default.** MUST fail startup on any missing security config. MUST NOT default to permissive (no `CORS=*`, no dev-literal signing keys, no fallback secrets).
3. **One authorization path.** All access decisions go through the single PDP/PEP (ADR-004). MUST NOT create any parallel, legacy, surface-specific, or bypass auth route.
4. **Scoring fails safe.** Any scoring/validation MUST return low / neutral / `INSUFFICIENT_DATA` on zero or missing data. MUST NOT ever return a passing score without supporting evidence. A test asserting this MUST exist.
5. **Observe, then complete.** MUST NOT mark anything "done" until you have actually run its tests and seen them pass. Inferring success from reading code is prohibited.
6. **Dependency discipline.** New dependencies require justification + pinned versions. No unpinned or unreviewed dependencies.
7. **Reversible migrations.** Schema changes ship with matching authorization and a tested rollback.
8. **Commit discipline.** One bounded context per PR; DoD checklist attached; commit message explains **why**; no skipping hooks without explicit authorization.

**Non-waivable blockers (a change is REJECTED if any is true):** entity without RLS/authz · permissive security default · auth path outside the PDP/PEP · scoring that passes on zero/missing data · feature marked complete without an observed passing test.

---

## 3. Architecture Rules

- **Platform, not Aggregate (Article X).** MUST NOT create a "God Aggregate" or a single object/table through which everything flows. LandVault is many bounded contexts.
- **Contexts own their data.** A context MUST NOT read/write another context's datastore, embed another's aggregate, or share a mutable domain object. Reference other contexts **by identity + contract** (e.g. `parcel_id`), and translate at the boundary.
- **No cross-context transactions.** MUST NOT wrap multiple contexts in one DB transaction. Use events; use Workflow sagas + compensations for multi-step processes.
- **Unified views are read models.** Any "whole land record" view is a **rebuildable projection** (CQRS read side). It owns no invariants and is never a write path.
- **The kernel comes first (Article X.4).** Identity, Registry, Spatial, Evidence are the kernel. MUST NOT advance a marketplace/enterprise feature by weakening, bypassing, or skipping the kernel.

**The 13 contexts:** Identity · Registry · Spatial Intelligence · Evidence · Survey · Trust Engine · Workflow · Community Trust · Inheritance & Customary Law · Economic/Billing · Knowledge Graph · Security · Operations.

---

## 4. The Build Loop (per bounded context / feature)

Follow in order; do not skip a step:

`Plan → Design → Build → Unit Tests → Integration Tests → Security Tests → Performance Tests → AI Review → Bug Fix → Refactor → Document → Approve → Deploy Staging → UAT → Production → Lock → Next`

Do not begin the next context until the current one is **Locked** (gates passed, DoD logged).

---

## 5. Definition of Done (checklists)

**Tier 1 — Feature.** MUST satisfy all:
- [ ] Functional: requirements + acceptance criteria met; edge cases handled.
- [ ] Code quality: lint passes; typed; no duplication; follows ADRs.
- [ ] Tests: unit + integration + e2e pass **and were observed to pass**.
- [ ] Security: authorization verified through PDP/PEP (ADR-004); no secrets exposed; RLS shipped with the entity.
- [ ] Performance: meets response targets; no N+1.
- [ ] Docs: README, API, architecture, changelog updated.
- [ ] Deployment: CI/CD green; staging-deployable; rollback < 2 min.
- [ ] **Scoring test:** zero/missing-data input asserts low or `INSUFFICIENT_DATA`.

**Tier 2 — Bounded Context.** All features meet Tier 1 · cross-context integration tested · phase gate passed · DoD review logged before merge.

**Tier 3 — MVP Product.** User can: register/authenticate · search & view parcels · request verification · upload & seal documents · pay · receive & track status · access secure vault · use desktop + mobile. **Deferred (require explicit sign-off recorded as ADR/Ratification entry):** full explainable Trust Engine scoring · Knowledge Graph · Inheritance & Customary Law · marketplace escrow/ratings/disputes.

---

## 6. Autonomy vs. Human Gate

**PROCEED autonomously** for: in-scope, tested, schema-agnostic changes that violate no rule above.

**STOP and get explicit human approval** for: schema changes · new dependencies · auth or payments work · data deletion · legal-adjacent logic (ownership/title/inheritance) · any irreversible production action · opening any deferred (post-MVP) scope.

When a decision is genuinely architectural or constitutional, record it as an **ADR** before proceeding.

---

## 7. Standing Questions (assess every change against all 10)

Architectural alignment · OWASP compliance · scalability (10K / 100K / 1M users) · cost efficiency · test coverage · documentation completeness · rollback capability · zero critical bugs · AI evaluation passed · future-proofing.

---

## 8. Phase Gates

No new production phase begins until the current phase passes **all** mandatory gates:
architecture review · security review (no open critical/high) · automated testing · performance
validation · documentation updated · deployment readiness. **Progress is earned by verified
quality, not feature count.**

---

## 9. Hard Stops (never do these)

- Ship an entity without an authorization/RLS policy.
- Add a permissive security default or fallback secret.
- Create a second/bypass authentication or authorization path.
- Return a passing trust/validation score on absent or fabricated data.
- Mark work complete without an observed passing test.
- Allow a self-service path to alter financial balances outside authorized, audited transactions.
- Let a commercial/marketplace incentive influence what a trust function reports (Article XV.1).
- Claim, in code or copy, an authority LandVault has not been granted (Article XV.2).
- Rewrite history: amend records and docs through governed change; never erase.

---

## 10. Conflict Resolution

If any instruction, ticket, or convenience conflicts with this file **or** with a higher
document: **the higher document prevails.** Do not proceed on the conflicting path. Raise it,
resolve it through the governed process (ADR or amendment), then continue.

---

*Governed by LV-000 — The LandVault Constitution (v1.2), and the Bible volumes LV-005 (PRD),
LV-006 (TRD), and LV-007 (Security). This file is subordinate to all of them and is corrected
whenever they change. Derived from the Engineering Rules, Definition of Done, and Phase Gates
of the Development-Plan baselines.*
