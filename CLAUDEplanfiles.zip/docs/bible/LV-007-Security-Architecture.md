# The Official LandVault Bible™

## Volume LV-007 — Security Architecture

*A subordinate volume of The Official LandVault Bible™, governed by LV-000 — The LandVault Constitution.*

---

## Document Control

| Field | Entry |
|---|---|
| **Document ID** | LV-007 |
| **Title** | Security Architecture |
| **Library** | The Official LandVault Bible™ |
| **Tier** | Bible (subordinate to the Constitution; elaborated by ADRs) |
| **Version** | v0.1 (Draft for Review) |
| **Status** | Draft — Under Authorship |
| **Classification** | Public (Governance) |
| **Owner** | Office of the LandVault Constitution (Governance Authority) |
| **Governed By** | LV-000 (v1.7); LV-005 (PRD); LV-006 (TRD) |
| **Governs** | Security implementation, review, and operational security procedures |
| **Source Baselines** | Development-Plan repository — Engineering Rules (8 non-negotiables), Definition of Done, ADR-004 (PDP/PEP), audit findings from prior builds |
| **Review Cycle** | Per phase gate (mandatory security review), and upon any security-relevant ADR |
| **Language** | English (UK) |

*Subordinate to LV-000. Security is treated here not as a feature set but as a property of
the platform's construction. Every control in this document exists because a specific,
confirmed failure made it necessary; none is included on the strength of theory alone.*

---

## 1. Purpose and Scope

This document specifies how the LandVault platform is secured. It states the platform's
security philosophy, a threat model grounded in confirmed findings, and the architecture of
authentication, authorisation, data isolation, configuration, validation, evidence and audit
integrity, financial security, fraud detection, incident response, secure delivery, and data
protection. It is written so that security can be **observed** — demonstrated by tests and
review that actually run — rather than asserted.

## 2. Security Philosophy

The platform's security philosophy follows directly from its founding lesson: a system that
asserts trustworthiness without proving it is more dangerous than one that makes no such
claim. Three commitments follow. Security is a property of **construction**, present from the
first line rather than inspected afterward. The system **fails safe**: in the absence of a
required control or of sufficient data, it denies, halts, or reports insufficiency rather than
proceeding permissively. And security is **evidenced by observation**: a control is not
considered present until a test has exercised it and been seen to pass.

## 3. Threat Model Grounded in Confirmed Findings

The platform's threat model is anchored in the specific, confirmed weaknesses of two prior
builds, each of which appeared functional and each of which was found on audit to be
exploitable. Every finding maps to a standing control.

- **Surface-only authorisation.** A prior build enforced authorisation only at the client or surface, leaving the underlying records reachable beneath it. *Control:* server-side authorisation through a single PDP/PEP, reinforced by database row-level security (§4–6).
- **Missing record isolation.** Entities shipped without row-level security or with public-write policies, so one party's data was not reliably isolated from another's. *Control:* every entity ships with an RLS/authorisation policy in the same change; a policy-less entity is a defect (§6).
- **Self-service financial fraud.** A wallet/financial path could be exploited to alter balances. *Control:* an atomic ledger with no self-service balance mutation outside authorised, audited transactions (§10).
- **Fabricated trust scores.** A validation engine reported a passing score regardless of evidence. *Control:* fail-safe validation — zero or missing data yields a low or `INSUFFICIENT_DATA` result, never a passing one, with a test asserting it (§8).
- **Parallel and undocumented authentication, and an admin bypass.** A second, undocumented auth path and an unauthenticated admin-login bypass circumvented the intended controls. *Control:* a single authorisation path with no parallel or legacy route, and no bypass (§5).
- **Permissive configuration defaults.** Cross-origin policy defaulted to `*` and signing keys fell back to development literals when unset. *Control:* secure-by-default configuration that fails hard when a security setting is missing (§7).

Because each threat is a confirmed exploitation path rather than a hypothetical, its control
is non-negotiable and non-waivable.

## 4. Authentication Architecture

Authentication is delegated to the platform's identity provider (Keycloak or Auth0) and
integrated through the single authorisation path. Token lifecycle — issuance, refresh, and
revocation — is managed centrally, with short-lived access credentials and controlled
refresh, and immediate revocation available when a session or delegation is withdrawn. There
is one authentication mechanism; no legacy or parallel login exists, and no administrative
interface is reachable without full authentication.

## 5. Authorisation Architecture

All authorisation decisions resolve through a single Policy Decision Point and Policy
Enforcement Point, informed by Policy Information where needed, as recorded in ADR-004. No
resource is reachable except through this path. The architecture provides **no** parallel,
legacy, surface-specific, or bypass route to a protected resource; the multiplication of
portals and integrations multiplies presentation only, never the authorisation model
(Article X.3). Authorisation is defined together with the data it protects: a new entity and
its authorisation policy are introduced in the same change.

## 6. Data Isolation

Authorisation is defended beneath the surface as well as at it. PostgreSQL row-level security
enforces tenant and record isolation in the database itself, so that even a flaw at the
application layer does not expose one party's records to another. Every table that holds
protected data carries an RLS policy from the moment it exists; the absence of such a policy
halts the change rather than deferring the control.

## 7. Secure-by-Default Configuration

Security configuration has no permissive fallback. A missing required setting — a signing key,
a cross-origin policy, a credential — causes the system to fail to start rather than to
default to a permissive state. Cross-origin policy is explicit and restrictive; signing keys
are supplied through managed secret storage and never fall back to development literals;
secrets are never embedded in code or logs. This posture exists because permissive defaults
and fallback development secrets were confirmed weaknesses in a prior build.

## 8. Fail-Safe Validation as a Security Property

Automated assessment is treated as a security-relevant function, because a validation engine
that overstates confidence is itself an attack surface against trust. Every scoring or
validation signal fails safe: where evidence is absent, incomplete, or unverifiable, the
result is low or explicitly insufficient, never passing. This behaviour is enforced by tests
that assert a zero-data or missing-data input yields a low or `INSUFFICIENT_DATA` outcome, and
no code path may return a favourable result on unsupported data.

## 9. Evidence and Audit Integrity

Evidence integrity is a security control as well as a data one. Artefacts are hashed on
receipt, sealed write-once, and anchored so that alteration is detectable; sealed evidence
cannot be modified in place. The audit trail is immutable, attributable, and tamper-evident,
recording consequential actions with the identity of the actor. Together these ensure that
neither the evidence nor the record of who did what can be quietly rewritten.

## 10. Financial Security

The Economic/Billing context enforces financial integrity through an atomic ledger. Balances
change only through authorised, audited, atomic transactions; no self-service path permits a
user to alter a balance directly, closing the financial-fraud vector confirmed in a prior
build. Payment integration (Paystack) is mediated by the ledger, and payment webhooks are
verified before they affect state.

## 11. Fraud Detection and the Security Context

The dedicated Security context provides fraud detection, security-incident handling, and
permission auditing across the platform. It observes patterns that individual contexts cannot
see in isolation, flags anomalies, and supports the periodic auditing of permissions to detect
drift from intended access. It consumes signals from other contexts by contract and does not
itself become a bypass of their controls.

## 12. Incident Response

The platform maintains a defined incident-response posture: detection through observability and
the Security context, containment through the ability to revoke sessions and delegations
immediately, investigation through the immutable audit trail, and recovery through tested
backup and rollback. Security incidents and their resolutions are recorded, and material
security decisions are captured as ADRs so that the platform's defences improve through
governed change rather than ad-hoc fixes.

## 13. Secure Delivery and Verification

Security is verified continuously rather than at the end. No feature is complete until its
security-relevant tests have been observed to pass. New dependencies are admitted only with
justification and pinned versions, limiting supply-chain exposure. Schema changes are
reversible and ship with their matching authorisation. Each phase gate includes a mandatory
security review, and no new production phase begins while a critical or high-severity finding
is open. Security expectations are aligned to recognised standards (for example OWASP), and the
platform's construction is assessed against them as a standing question rather than a one-time
audit.

## 14. Data Protection and Privacy

Personal information is protected in proportion to its sensitivity. Family and inheritance data
receive particular care, consistent with the deferral of the Inheritance & Customary-Law
capability to a stage where its privacy controls can be built deliberately. Access to personal
data is governed by the same single authorisation path and row-level isolation as all other
protected data, and its handling is auditable.

## 15. Traceability

Every control here answers to the Constitution. The single-authorisation-path and
no-bypass requirements implement Article X.3 and the platform's authorisation rule. The
fail-safe validation requirement implements the engineered-trust mandate (Article II.3). The
evidence and audit integrity requirements implement the mission's preservation duty and the
amend-don't-erase principle (Article IV; §E.3). The financial-integrity and neutrality
controls support the Trust Neutrality Firewall (Article XV.1). Where this document and a higher
document could be read to differ, the higher document prevails, and this document is reconciled
through a recorded ADR.

---

*End of LV-007 — Security Architecture (Draft v0.1). Governed by LV-000 (v1.7), LV-005, and LV-006. Submitted for review.*
