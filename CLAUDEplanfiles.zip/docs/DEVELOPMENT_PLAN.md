# LandVault — Development Plan (Execution)

- **Status:** Approved — active execution plan for the MVP / pilot.
- **Governed by:** LV-000 v1.7 (Constitution) and the Bible in `docs/bible/`; enforced by the
  non-negotiable rules in `docs/bible/LandVault-CLAUDE.md` and this repo's `CLAUDE.md`.
- **ADRs it depends on:** Registry Ownership & Status History; Delivery Platform Decisions
  (StoragePort/R2/WORM, Keycloak, Paystack); Pilot Non-Functional Targets. (In `docs/adr/`.)
- **Prime directive:** LandVault preserves and verifies land evidence. **It does not decide who
  owns land.** No code, schema, API, or UI may assert title or ownership adjudication.

> **For Claude Code / any agent:** read `CLAUDE.md` (→ this plan + the blueprint), then for each
> task run `/plan <bounded-context>`, build against the plan, run the tests, and `/review` before
> committing. One bounded context per PR. Nothing is "done" until its tests have been **observed**
> to pass.

---

## 1. Current state (verify before building)

Per the latest working-tree assessment (re-confirm by observation — do not inherit on faith):

- **Frozen & verified:** B1 Identity, B2 Tenant/Delegation, B3 Registry (parcel numbering, RLS,
  audit chain, geometry seam). Reported at 119/119 backend tests — **re-run `pytest` on the
  untouched tree and confirm green before Phase 1.**
- **Geometry seam:** the current adapter accepts every reference (a boundary, not validation). B4
  Spatial replaces the adapter behind `GeometryPort` **without changing Registry's domain contract.**
- **Frontend:** F0 shell (landing page + component base). No authenticated portals, API client, or
  parcel journeys yet.
- **Infra gaps:** Keycloak in dev mode; Terraform pinned but no provider/resources; no CI.
- **Working tree:** finish or revert any paused test/lockfile changes so the tree is clean before
  new work.

---

## 2. MVP boundary (pilot)

Deliver **four governed portals — customer, survey partner, enterprise (read), government
operations — sharing one Next.js app and the single PDP/PEP authorisation path** (Article X.3).

**MVP must support:** authenticated parcel search & registration · spatial validation · evidence
sealing · verification requests · licensed assignment · status tracking · secure vault access ·
payment. **It must never claim title or ownership adjudication.**

**Deferred to post-pilot (require recorded sign-off to build):** full multi-signal Trust Engine
scoring · Community Trust · Inheritance & Customary Law · Knowledge Graph · Marketplace escrow,
ratings & disputes. (Per LV-005 §4.2.)

---

## 3. Approved decisions (binding for this plan)

1. **Registry ownership/status history** — keep the current owner reference on the Parcel aggregate
   (domain contract unchanged); add an **append-only history table owned by Registry**; emit domain
   events; history is *recorded assertions* with provenance, **never** a title determination. RLS in
   the same migration; reversible/rollback-tested; writes to the B1 audit chain; cross-tenant tests.
2. **Storage** — provider-agnostic **StoragePort** (S3-compatible + object-lock capability);
   **Cloudflare R2** default for the pilot; adapters for S3/Azure/GCS/MinIO. Sealed evidence must be
   under WORM; the adapter **declares its WORM grade** (R2 Bucket Locks = *governance-grade*,
   admin-revocable; S3 Object Lock compliance / Azure / GCS / MinIO = *compliance-grade*,
   irrevocable + legal hold). Confirm required grade with the pilot partner/counsel.
3. **IdP** — Keycloak confirmed; move to production mode (DB, TLS, realm-as-code, secrets manager).
4. **Payments** — Paystack only for pilot one; Stripe deferred.
5. **Targets** — reads p95 < 300–500 ms; search < 1 s; availability 99.5%; RPO ≤ 15 min /
   RTO ≤ 1 h; WCAG 2.1 AA; zero open critical/high; pilot success = N parcels registered
   end-to-end, X% verification requests fulfilled with recorded evidence, restore + rollback
   demonstrated. (Fix N/X with the pilot partner.)

---

## 4. Phase plan

| Phase | Outcome | Main work | Gate to proceed |
|---|---|---|---|
| **0 — Stabilise delivery** | Trustworthy baseline | Re-observe backend green; resolve `npm test`; CI (frontend+backend); branch/PR checks; verify local Docker; Keycloak realm-as-code + secrets; StoragePort skeleton + R2 adapter; choose compute at deploy | Clean tree, CI green, repeatable env, staging design approved |
| **1 — Registry contract** | B3 aligns with PRD | Implement the ownership/status-history ADR (migration + RLS + events + audit + cross-tenant tests + non-adjudication check) | ADR implemented; migration/RLS/rollback/cross-tenant tests pass |
| **2 — B4 Spatial + F1/F2** | Real spatial registry MVP | PostGIS geometry versions, CRS + topology checks, overlap/duplicate detection, spatial search via `GeometryPort` (Registry contract unchanged); **F1** authenticated shell + API client, then **F2** registration/search/map/parcel-detail UI | Invalid/missing-CRS rejected; overlaps surfaced; RLS + perf pass; real registration works end-to-end through an authenticated portal |
| **3 — B5 Evidence + F3 vault** | Evidence-backed parcels | StoragePort sealed writes (WORM), streamed hashing + read-back verification, chain of custody, integrity verification, legal-hold hook; upload + evidence timeline + authorised vault UI | Sealed evidence cannot be altered; integrity check demonstrated; storage/retention/break-glass pass security review |
| **4 — B8 Workflow + B6 Survey** | Verification requested & fulfilled | Verification state machine, events, SLAs, compensations; licensed surveyor/firm onboarding, assignment, survey-plan submission via Evidence; requester status tracking; work queues | End-to-end request assigned only to an eligible surveyor, records evidence, shows traceable status |
| **5 — B11 Billing + payment UI** | Paid verification, safely | Atomic ledger, invoice lifecycle, webhook verification/idempotency, payment→workflow contract; Paystack | No direct balance mutation; duplicate webhooks harmless; reconciliation + refund tested |
| **6 — Pilot hardening** | Staging-ready MVP | Security sweep; ops: monitoring, alerts, audit review, backups/restore, load tests, runbooks, deploy/rollback rehearsal; public verification; responsive/mobile polish | No open critical/high; restore + rollback demonstrated; pilot UAT passes |

---

## 5. Phase 0 — Stabilise delivery (detail)

1. **Re-observe the baseline.** `cd backend && pytest` (+ Ruff, mypy). Confirm green *now*. Record it.
2. **Resolve `npm test`.** Either set `"test": "tsc --noEmit && next lint"` (zero-dependency
   placeholder) **or** adopt Vitest (a governed dependency addition — approve per Rule 6). Then the
   tree is clean.
3. **CI.** Add `.github/workflows/backend-ci.yml` and `frontend-ci.yml` (in this pack). Make them
   green on a PR.
4. **Branch/PR checks.** Require CI + review before merge; one bounded context per PR.
5. **Local Docker** workflow verified end-to-end.
6. **Keycloak** realm exported as code + committed; secrets to a manager; off dev mode.
7. **StoragePort skeleton + R2 adapter** (see §6.2) so Evidence has a seam from the start.
8. **Compute** provider chosen at deploy (storage is already decoupled).

**Gate:** clean tree, CI green, repeatable local env, staging design approved → Phase 1.

---

## 6. Phase 1 — Registry ownership/status history (implementation)

Implements the Registry Ownership & Status History ADR. **Do not touch B4/Spatial here.**

### 6.1 Data model & migration
- New append-only tables owned by Registry, e.g. `parcel_ownership_history`, `parcel_status_history`.
- Columns (minimum): `id`, `tenant_id`, `parcel_id`, `asserted_holder_ref`, `basis` (the
  document/authority the assertion derives from), `recorded_by`, `recorded_at`, `audit_ref`,
  `supersedes_id` (nullable). **Immutable/append-only** — corrections add a row.
- The Parcel aggregate keeps its **current** owner reference; its domain contract is **unchanged**.
- **Migration ships its RLS/tenant policy in the same migration** (Rule 1) and has a tested `down`
  (Rules 6–7). Rehearse rollback on a staging-like DB.

### 6.2 StoragePort (introduced now, used by Evidence in Phase 3)
- Define `StoragePort` (put/get/list + `putImmutable(retention)` / lock capability + `wormGrade()`
  returning `compliance` | `governance`). Implement the **R2 adapter** (Bucket Locks →
  `governance`). No context calls a storage SDK directly.

### 6.3 Events & audit
- Registry emits `ParcelOwnershipRecorded` / `ParcelOwnershipChanged` / `ParcelStatusChanged`.
- Every change writes to the **B1 audit chain**, attributable to an authenticated actor; each
  history row references its audit entry (`audit_ref`).

### 6.4 Access
- All reads/writes of history resolve through the **PDP/PEP** (ADR-004). No table-level bypass.

### 6.5 Non-adjudication safeguard
- Schema/API/UI present history as **recorded assertions of ownership** with basis and provenance.
  No field, label, or response asserts title. Add a test/lint that fails on ownership-adjudication
  wording in responses.

### 6.6 Test matrix (must be observed to pass)
- Duplicate/append correctness; append-only enforced (no in-place update).
- **Cross-tenant isolation** — tenant A cannot read or write tenant B's history (positive + negative).
- Audit entry created per change; `audit_ref` resolves.
- Events emitted with correct payload/contract.
- Migration up **and** down; rollback rehearsed.
- Parcel aggregate regression: current-owner behaviour unchanged.
- Non-adjudication wording check.
- PII/retention: superseded rows retained; access audited. (Retention/erasure posture per counsel —
  log the item; do not silently implement erasure.)

**Gate:** all of §6.6 green and observed; `/review` clean → Phase 2.

---

## 7. Phases 2–6 (build order & gates)

Follow the table in §4. Key rules throughout:
- **Kernel first** (identity/registry/spatial/evidence) before marketplace/enterprise features (Art X.4).
- **Integration by contract** — contexts own their data; events between contexts; no cross-context
  transactions; unified views are read-model projections (Art X).
- **F1 before F2** — the frontend authenticates a real user through Keycloak and makes one authorised
  API call before any parcel-journey UI is built on top.
- Evidence sealed writes go **through StoragePort**; the active sealed-evidence WORM grade is
  recorded, and escalated to a compliance-grade backend if the pilot requires it (no code change).

---

## 8. Definition of Done & gates (recap)

- **Feature (Tier 1):** requirements met; authZ via PDP/PEP; unit+integration+e2e tests observed
  green; RLS shipped with any new entity; perf targets; docs updated; scoring fails safe on missing
  data; staging-deployable with rollback.
- **Context (Tier 2):** all features Tier-1; cross-context integration tested; phase gate passed;
  DoD review logged before merge.
- **Pilot (Tier 3):** MVP journeys (§2) complete end to end; deferred items remain out of scope;
  pilot targets met; restore + rollback demonstrated; zero open critical/high.
- **Phase gates:** no new phase begins until the current phase passes architecture, security,
  testing, performance, documentation, and deployment review.

---

## 9. Pending human decisions (resolve at the named gates)

- **Pilot jurisdiction, surveyor eligibility, source-data-authority MOU** — needed by Phase 4;
  from the anchor-tenant conversation (LV-013).
- **Data residency & required WORM grade** — needed by Phase 3 (selects the sealed-evidence adapter).
- **N / X pilot-success numbers** — fix with the pilot partner; record in the targets ADR.

These are decisions, not code — the build proceeds around them and stops only where a gate needs them.

---

## 10. Start here (first work, in order)

1. **PR-0.1:** re-observe backend green (`pytest`/Ruff/mypy); record result.
2. **PR-0.2:** set the `npm test` script (placeholder or approved Vitest); clean the working tree.
3. **PR-0.3:** add CI workflows; make them green.
4. **PR-0.4:** branch protection / PR checks; Keycloak realm-as-code + secrets.
5. **PR-1.x (Phase 1):** implement the ownership/status-history ADR per §6 — one PR for the
   migration+RLS+events+audit+tests. `/review` before merge.

Only after Phase 0's gate is met does Phase 1 begin; only after Phase 1's gate does B4 Spatial begin.
