# ADR — Pilot Non-Functional Targets

- **ADR ID:** ADR-NNN  *(assign next available number)*
- **Status:** Accepted (approved)
- **Date:** 2026-07-27
- **Deciders:** Platform Owner / Governance Authority
- **Governed by:** LV-000 (Articles II.3, IV.5); LV-005 §6 (NFRs); LV-007; LV-011 (accessibility); LV-015 (reliability/recovery)

## Context

The Bible defined non-functional expectations qualitatively (load tiers, WCAG AA, fail-safe,
tested recovery) but without pilot-scale numbers. Concrete, measured targets are set here so
"observe, then complete" can be applied and the pilot has a defined success bar. Targets are
**pilot-scale, not hyperscale** — deliberately modest to avoid over-engineering before demand is
proven (Article IV.5).

## Decision — target values

### Performance
- **Reads p95 < 300–500 ms** (API, typical authorised read).
- **Parcel search < 1 s** (typical query at pilot data volumes).
- Queries optimised; **no N+1** patterns (LV-005 NFR-3).

### Availability
- **99.5%** during pilot (explicitly *not* 99.9%+; that is a scale-up target, not a pilot one).

### Recovery
- **RPO ≤ 15 minutes** (max acceptable data loss).
- **RTO ≤ 1 hour** (max acceptable time to restore).
- Backup **and restore** are *tested*, not assumed (LV-015 §6); rollback rehearsed.

### Accessibility
- **WCAG 2.1 AA**, mobile-first and low-bandwidth-aware (LV-010, LV-011).

### Security
- **Zero open critical/high-severity findings** at pilot gate (LV-007; phase gate 8).

### Pilot success criteria
- **N** parcels registered end-to-end (tune **N** with the pilot partner).
- **X%** of verification requests fulfilled with recorded evidence (tune **X** with partner).
- Zero open critical/high security findings.
- A **demonstrated restore + rollback** (not merely documented).

## Consequences

- These become measurable gate conditions for Phase 6 (pilot hardening) and inform SLO monitoring
  from Phase 0.
- **N** and **X** are intentionally left to be fixed in the anchor-tenant conversation (LV-013);
  this ADR is updated with those values once the pilot jurisdiction and partner are confirmed.

## Definition-of-Done

- [ ] SLO monitoring for the target metrics stood up in Phase 0.
- [ ] N and X fixed with the pilot partner and recorded here.
- [ ] Restore + rollback demonstrated before pilot go/no-go.
