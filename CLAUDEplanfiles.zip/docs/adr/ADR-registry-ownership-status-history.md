# ADR — Registry: Retained Ownership & Status History

- **ADR ID:** ADR-NNN  *(assign the next available number; supersedes/amends the Registry/Parcel-aggregate ADR and references ADR-004 Authorisation)*
- **Status:** Accepted (approved by the Governance Authority)
- **Date:** 2026-07-27
- **Deciders:** Platform Owner / Governance Authority
- **Governed by:** LV-000 (Articles I.2, IV, IV.4, XII, XV.2, §E.3); LV-005 FR-6; LV-006 §§4–7; LV-009 §§2–3, 9–11; LV-007
- **Amends:** frozen Phase B3 (Registry). References: ADR-004 (single PDP/PEP authorisation); ADR-<Registry> (Parcel aggregate & parcel numbering — insert real number).

## Context

LV-005 (PRD) **FR-6** requires that "a parcel's ownership and status history shall be retained."
Frozen B3 stores only a **current** ownership reference on the Parcel aggregate. This is a
genuine conflict between a governing document and the implementation, and — because Article IV
(preserve), Article XII (history retained, not overwritten), and §E.3 (amend, don't erase) all
favour retaining history — the resolution is to **add history**, through this recorded ADR, and
never silently during Spatial (B4) work.

A hard constraint frames everything below: **the platform does not decide who owns land**
(Articles I.2, IV.4). The history recorded here is *evidentiary and asserted* — it records who was
**recorded as** holder, on what basis, by whom, and when — not an adjudication of title.

## Decision

1. **The Parcel aggregate keeps its current owner reference** as a fast, transactional invariant.
   Its existing domain contract is **unchanged**. (Approved.)
2. **Ownership and status history is an append-only table owned by the Registry context**
   (e.g. `parcel_ownership_history`, `parcel_status_history`) — the same consistency boundary as
   the Parcel aggregate, not a new bounded context. (Approved.)
3. **Registry emits domain events** on every change (`ParcelOwnershipRecorded` /
   `...Changed`, `ParcelStatusChanged`) so other contexts can consume them by contract, per
   Article X and LV-006 §5. History is authoritative in Registry; other contexts may build their
   own projections from the events.
4. A **separate history bounded context is explicitly deferred** — reserved only if history later
   needs independent scaling or ownership. (Approved.)

Each history row records, at minimum: parcel id, the asserted holder reference, the **basis**
of the assertion (the document/authority it derives from), the actor who recorded it, the
timestamp, and a link to the audit entry. Rows are **immutable and append-only**; a correction is
a new row, never an in-place edit (§E.3).

## Non-negotiables this change must satisfy (gating)

- **RLS in the same migration (Rule 1).** The history tables ship with their row-level-security /
  tenant-scoping policy in the *same* migration that creates them. A history table without a
  policy is a non-waivable blocker.
- **Reversible & rollback-tested migration (Rules 6–7).** The migration has a tested `down` path
  and is rehearsed before production.
- **Audit chain (B1).** Every ownership/status change writes to the existing B1 audit chain,
  attributable to an authenticated actor, and each history row references its audit entry.
- **Cross-tenant isolation tested.** Tests prove one tenant cannot read or write another tenant's
  ownership/status history (positive and negative cases).
- **Single authorisation path (ADR-004).** All reads/writes of history resolve through the PDP/PEP;
  no direct/table-level access path is introduced.

## PII, retention & protection posture (Article XII; Nigerian data-protection law)

Ownership references are **likely personal data**. Therefore:

- **Retention:** ownership/status history is retained for the life of the parcel record as land
  evidence (it is part of what the platform exists to preserve); it is not deleted on ownership
  change — superseded entries remain as history.
- **Protection:** history is classified as personal/sensitive, protected by RLS and the single
  authorisation path, encrypted in transit and at rest, and access is auditable.
- **Data-subject handling** (rectification/erasure requests, lawful basis) is to be mapped against
  applicable Nigerian data-protection law **with counsel**; because the record is also statutory
  land evidence, erasure may be constrained — this tension is flagged here and resolved with the
  pilot jurisdiction's legal framework, not decided unilaterally in code.

## Non-adjudication safeguard

The schema, API, and any UI over this history shall present it as **recorded assertions of
ownership**, with their basis and provenance — never as a determination that a party *owns* the
parcel. No field, label, or response asserts title. (Articles I.2, IV.4, XV.2.)

## Alternatives considered

- **Event-sourced-only history (no authoritative table).** Purer CQRS, but adds operational
  complexity and makes RLS-scoped authoritative queries harder for the MVP. Deferred.
- **Separate "Ownership History" bounded context.** Cleaner isolation, but unjustified overhead at
  pilot scale; would fragment a single consistency concern. Deferred until independent
  scaling/ownership is actually needed.

## Consequences

- **Positive:** the platform now conforms to LV-005 FR-6 and to the Constitution's preservation
  duty; ownership provenance becomes examinable; other contexts can subscribe to the events.
- **Cost:** one reversible migration, RLS policies, event emission, and a test suite (unit +
  cross-tenant + audit assertions) before B4 begins.
- **Sequencing:** this ADR is implemented in **Phase 1 (Resolve Registry contract)**, *before* B4
  Spatial work, so Spatial never has cause to touch Registry's ownership model.

## Definition-of-Done for this ADR's implementation

- [ ] History tables created **with** RLS/tenant policy in the same migration.
- [ ] Migration has a tested rollback; rehearsed on a staging-like DB.
- [ ] Ownership/status changes emit domain events and write to the B1 audit chain.
- [ ] Cross-tenant isolation tests (positive + negative) pass and are observed to pass.
- [ ] Parcel aggregate's existing domain contract is unchanged (regression tests green).
- [ ] No field/label/response asserts title (non-adjudication check).
- [ ] Retention & PII posture recorded; counsel review item logged for the pilot jurisdiction.
