# ADR — Delivery Platform Decisions (Storage Portability, Cloud, IdP, Pilot Payments)

- **ADR ID:** ADR-NNN  *(assign next available number — see `scripts/finalize-adrs.sh`)*
- **Status:** Accepted (approved)
- **Date:** 2026-07-27
- **Deciders:** Platform Owner / Governance Authority
- **Governed by:** LV-000 (Articles II.3, X.2, X.3, X.4, XV.1, XV.2); LV-006; LV-007; LV-008; LV-009; LV-012
- **References:** ADR-004 (single PDP/PEP authorisation); the Registry ownership-history ADR
- **External references:** Cloudflare R2 Bucket Locks docs; AWS S3 Object Lock docs (see §References)

## Context

Terraform carries version pins but no cloud provider or resources; Keycloak runs in development
mode; no evidence-storage or payment-provider decision was recorded. Rather than lock the platform
to one cloud, the decision is to keep object storage **provider-agnostic behind a port**, so the
concrete provider can change without touching domain code — consistent with Article X.2
(integration by contract) and the "S3-compatible object storage" wording already in LV-006/LV-009.

## Decisions

### 1. Object storage is provider-agnostic via an S3-compatible **StoragePort**

Evidence and other blob storage are accessed only through a **StoragePort** (an S3-compatible
interface: put/get/list + an explicit *object-lock / retention* capability). Concrete providers are
**swappable adapters** — Cloudflare R2, Amazon S3, Azure Blob Storage, Google Cloud Storage, or
self-hosted MinIO. No context reaches a storage SDK directly; the port is the only seam. This
preserves the freedom to branch providers later and keeps residency a deploy-time choice, not a
code dependency.

### 2. Pilot default backend — **Cloudflare R2**

R2 is the default for pilot one (egress-free, cost-effective, residency-flexible), i.e. "what we
build with now." Compute and the rest of the stack remain portable (Docker + Terraform); the cloud
*compute* provider is chosen at deploy and is **independent of** the storage choice.

### 3. Sealed-evidence WORM requirement (non-negotiable) — with an explicit **grade**

Sealed evidence MUST be written under a WORM/retention lock. Because providers differ, the
StoragePort adapter **declares the WORM grade** it enforces, and the platform records which grade is
in force for the sealed-evidence bucket:

- **Compliance-grade (irrevocable):** immutable until retention expires *even to an administrator/root*, with per-object retention and legal hold. Provided by **Amazon S3 Object Lock (compliance mode)**, **Azure Blob immutability policies + legal hold**, **GCS Bucket Lock**, or **MinIO Object Lock**.
- **Governance-grade (admin-revocable):** WORM that prevents deletion/overwrite for a period but whose rules a privileged account admin can remove. **Cloudflare R2 Bucket Locks** are governance-grade: bucket-level retention (prefix rules, precedence over lifecycle), **no compliance/governance mode distinction and no per-object legal hold** per Cloudflare's docs.

**Rule:** the sealed-evidence bucket must always be under *at least* the WORM grade the pilot's
legal/evidentiary requirements demand. R2 (governance-grade) is acceptable for the pilot **only if**
the pilot partner/counsel accept governance-grade WORM, compensated by separation of duties, the B1
audit chain, and alerting on any lock-rule change. Where **compliance-grade** or **legal hold** is
required, point the sealed-evidence bucket at S3 Object Lock (compliance), Azure, GCS, or MinIO —
**no code change**, because it is behind the StoragePort.

### 4. Production identity provider — **Keycloak (confirmed)**

Confirmed as production IdP (standards-based, self-hostable, matches B1). Move off dev mode:
production DB, TLS, hardened realm, **realm config exported as code and version-controlled**, and
**secrets in a manager** (never env literals / fallback dev secrets — secure-by-default rule).

### 5. Pilot payments — **Paystack only; Stripe deferred**

Pilot one uses Paystack (Nigerian market). Stripe is deferred and added only if a later pilot
includes diaspora payments. Payments sit behind the Economic/Billing atomic ledger with webhook
verification and idempotency (LV-009 §8); no direct balance mutation.

## Residency

The StoragePort resolves the earlier residency concern structurally: evidence can be placed on a
provider/region (or self-hosted MinIO) that meets in-country requirements without changing code.
Confirm the pilot jurisdiction's residency and WORM-grade requirements with counsel; the answer
selects the adapter, not the architecture.

## Consequences

- **Positive:** no cloud lock-in; residency and WORM grade become configuration; portability aligns with Article X.2.
- **Cost:** one storage-abstraction seam (a StoragePort + at least one adapter) and a documented WORM-grade for the active sealed-evidence backend.
- **Watch item:** if the pilot needs compliance-grade WORM or legal hold, R2 alone is insufficient for sealed evidence — plan the sealed-evidence bucket on a compliance-grade backend from the start, even while other blobs live on R2.

## Definition-of-Done

- [ ] StoragePort defined (S3-compatible + object-lock/retention capability); no direct SDK use in contexts.
- [ ] Pilot R2 adapter implemented; sealed-evidence bucket under a Bucket Lock; WORM grade recorded as *governance-grade*.
- [ ] Alerting on any bucket-lock-rule change; separation of duties enforced on the storage account.
- [ ] Pilot partner/counsel confirm whether governance-grade WORM suffices or compliance-grade/legal-hold is required; if the latter, sealed-evidence adapter set to S3/Azure/GCS/MinIO.
- [ ] Keycloak in production mode: DB, TLS, realm-as-code, secrets in a manager; no dev fallbacks.
- [ ] Paystack behind the atomic ledger; webhook verification + idempotency tested.

## References

- Cloudflare R2 — Bucket Locks (bucket-level WORM; prefix rules; no compliance/governance modes or per-object legal hold): https://developers.cloudflare.com/r2/buckets/bucket-locks/
- Amazon S3 — Object Lock (compliance/governance modes, legal hold; compliance mode immutable to root): https://docs.aws.amazon.com/AmazonS3/latest/userguide/object-lock.html
