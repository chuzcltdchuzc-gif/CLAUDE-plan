# LandVault — Claude Code Project Memory

Claude Code loads this automatically at the start of every session in this repository. It imports
the agent-agnostic instructions and the governing blueprint so all planning and execution are
governed by the constitution and rules beneath it.

## Shared, cross-agent instructions

@AGENTS.md

## Governing blueprint (imported into context)

@docs/bible/LandVault-CLAUDE.md
@docs/bible/LV-005-Product-Requirements-PRD.md
@docs/bible/LV-006-Technical-Requirements-TRD.md
@docs/bible/LV-007-Security-Architecture.md

> The full library (LV-000 Constitution through LV-016) is in `docs/bible/`. Read the others on
> demand; the four above are the ones needed for build-time planning.

## Claude Code specifics

- **Plan mode:** press `Shift+Tab` to cycle into plan mode (read-only planning before edits), or
  launch `claude --permission-mode plan`. Use it for any non-trivial change.
- **`/plan <context>`** — scoped, read-only execution plan for one bounded context (see
  `.claude/commands/plan.md`).
- **`/review <context-or-diff>`** — adversarial second-opinion review against the blueprint (see
  `.claude/commands/review.md`).
- **Subagents:** `planner` (read-only build planning) and `reviewer` (read-only second opinion) are
  defined in `.claude/agents/`.
- **Test commands are pre-authorised** in `.claude/settings.json` so the agent can observe the suite.
- Add directories outside this repo with `--add-dir <path>`; pull a specific file into a prompt with
  `@path/to/file`.

The rules and workflow live in `AGENTS.md` and `docs/bible/LandVault-CLAUDE.md` above — follow them.
