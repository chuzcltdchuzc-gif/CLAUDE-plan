#!/usr/bin/env bash
# ------------------------------------------------------------------------------
# LandVault — local setup (MERGE-not-clobber CLAUDE.md fix)
# Clones/updates Development-Plan and merges the agent bundle WITHOUT destroying
# the repository's own CLAUDE.md (its operational/freeze history is preserved as
# CLAUDE.repo.md and imported by the merged root CLAUDE.md).
#
# Run this from the directory that CONTAINS the bundle files (CLAUDE.md, AGENTS.md,
# .claude/, docs/bible/) — i.e. the unzipped kit folder.
#
# Usage:
#   ./setup-landvault-local.sh [--with-deps]
#   REPO_URL=<url> ./setup-landvault-local.sh
# ------------------------------------------------------------------------------
set -euo pipefail

REPO_URL="${REPO_URL:-https://github.com/chuzcltdchuzc-gif/Development-Plan.git}"
TARGET="${TARGET:-Development-Plan}"
HERE="$(cd "$(dirname "$0")" && pwd)"
WITH_DEPS="no"; [ "${1:-}" = "--with-deps" ] && WITH_DEPS="yes"

command -v git >/dev/null 2>&1 || { echo "ERROR: git not installed."; exit 1; }

echo "==> Repository: $REPO_URL"
if [ -d "$TARGET/.git" ]; then
  echo "==> Updating existing '$TARGET' ..."
  git -C "$TARGET" pull --ff-only || echo "   (pull skipped — resolve manually if needed)"
else
  echo "==> Cloning into '$TARGET' ..."
  git clone "$REPO_URL" "$TARGET" || {
    echo "ERROR: clone failed. If private: 'gh auth login', or use SSH:"
    echo "  REPO_URL=git@github.com:chuzcltdchuzc-gif/Development-Plan.git $0"; exit 1; }
fi

echo "==> Merging agent bundle (preserving the repo's own CLAUDE.md) ..."

# 1. Preserve the repository's existing CLAUDE.md as CLAUDE.repo.md (do NOT clobber it).
if [ -f "$TARGET/CLAUDE.md" ] && [ ! -f "$TARGET/CLAUDE.repo.md" ]; then
  # Only preserve if it isn't already our merged file.
  if ! grep -q "CLAUDE.repo.md" "$TARGET/CLAUDE.md" 2>/dev/null; then
    echo "   - preserving repo CLAUDE.md -> CLAUDE.repo.md"
    mv "$TARGET/CLAUDE.md" "$TARGET/CLAUDE.repo.md"
  fi
fi
# Ensure the import target exists so @CLAUDE.repo.md never dangles.
[ -f "$TARGET/CLAUDE.repo.md" ] || printf "# (repository had no prior CLAUDE.md)\n" > "$TARGET/CLAUDE.repo.md"

# 2. Install the merged root CLAUDE.md (imports CLAUDE.repo.md + AGENTS.md + blueprint).
cp "$HERE/CLAUDE.md" "$TARGET/CLAUDE.md"

# 3. AGENTS.md + .claude/ + docs/bible/ (+ docs/adr/ if present in the kit).
cp "$HERE/AGENTS.md" "$TARGET/AGENTS.md" 2>/dev/null || true
mkdir -p "$TARGET/.claude" "$TARGET/docs/bible" "$TARGET/docs/adr"
[ -d "$HERE/.claude" ] && cp -R "$HERE/.claude/." "$TARGET/.claude/"
[ -d "$HERE/docs/bible" ] && cp -R "$HERE/docs/bible/." "$TARGET/docs/bible/"
[ -d "$HERE/docs/adr" ] && cp -R "$HERE/docs/adr/." "$TARGET/docs/adr/"
echo "   - CLAUDE.md (merged), CLAUDE.repo.md (preserved), AGENTS.md, .claude/, docs/bible/, docs/adr/"

if [ "$WITH_DEPS" = "yes" ]; then
  [ -f "$TARGET/frontend/package.json" ] && command -v npm >/dev/null 2>&1 && ( cd "$TARGET/frontend" && npm install ) || true
  [ -f "$TARGET/backend/requirements.txt" ] && command -v python3 >/dev/null 2>&1 && \
    python3 -m venv "$TARGET/backend/.venv" && "$TARGET/backend/.venv/bin/pip" install -q -r "$TARGET/backend/requirements.txt" || true
fi

cat <<EOF

==> Done. '$TARGET' is ready, with its own CLAUDE.md preserved as CLAUDE.repo.md.

  cd $TARGET && claude      # Shift+Tab = plan mode; /plan <ctx>; /review <ctx>
  Tests:  cd frontend && npm test    |    cd backend && pytest
EOF
