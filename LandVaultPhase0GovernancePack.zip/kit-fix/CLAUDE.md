# LandVault — Claude Code Project Memory (merged)

Claude Code loads this automatically. It preserves the repository's own operational memory and
layers the governing blueprint on top. Order matters: the repo's own CLAUDE (freeze state,
operational history) is authoritative on *current build state*; the Bible is authoritative on
*principles and requirements*. Neither may contradict LV-000.

## Repository's own memory (preserved — do not delete)

@CLAUDE.repo.md

## Shared, cross-agent instructions

@AGENTS.md

## Governing blueprint

@docs/bible/LandVault-CLAUDE.md
@docs/bible/LV-005-Product-Requirements-PRD.md
@docs/bible/LV-006-Technical-Requirements-TRD.md
@docs/bible/LV-007-Security-Architecture.md

> Full library (LV-000 … LV-016) in `docs/bible/`. Architecture Decision Records in `docs/adr/`.

## Precedence

1. `docs/bible/LV-000` (Constitution) — supreme.
2. The rest of the Bible (`docs/bible/LV-001…LV-016`) and ratified ADRs (`docs/adr/`).
3. `CLAUDE.repo.md` — authoritative on **current freeze/phase state and operational history**
   (e.g. B1–B3 frozen; approval required before B4/Spatial).
4. `AGENTS.md` / this file — build workflow and commands.

Where the repo's memory and the blueprint appear to disagree about *what to build*, the blueprint
(PRD/TRD) governs and the disagreement is resolved through an ADR. Where they disagree about
*current state* (what is frozen, what tests pass), `CLAUDE.repo.md` and the actual test run win —
**observe the suite, don't assume it.**

## Claude Code specifics

- Plan mode: `Shift+Tab` (read-only planning) or `claude --permission-mode plan`.
- `/plan <context>` — scoped execution plan.  `/review <target>` — second-opinion review.
- Subagents `planner` / `reviewer` in `.claude/agents/`. Test commands pre-authorised in
  `.claude/settings.json`.
