# LandVault — Phase 0 Governance Pack

Ready-to-commit artifacts for the approved decisions, so Phase 0 ("Stabilise delivery") can begin
under governance. Everything here is subordinate to LV-000 and the Bible in `docs/bible/`.

## Contents

```
docs/adr/
  ADR-registry-ownership-status-history.md   # the approved Registry contract resolution (LV-005 FR-6 vs frozen B3)
  ADR-delivery-platform-decisions.md         # provider-agnostic StoragePort (R2 default), WORM-grade rule, Keycloak, Paystack-only pilot
  ADR-pilot-nonfunctional-targets.md         # p95, availability, RPO/RTO, WCAG AA, pilot success criteria
.github/workflows/
  backend-ci.yml                             # pytest + Ruff + mypy
  frontend-ci.yml                            # lint + typecheck + build + (test if present)
scripts/
  finalize-adrs.sh                           # assigns next ADR numbers + fills cross-references (run in repo)
kit-fix/
  CLAUDE.md                                  # merged root memory that PRESERVES the repo's own CLAUDE.md
  setup-landvault-local.sh                   # merge-not-clobber setup (fixes the earlier overwrite)
```

## How to apply

1. **ADRs** — copy `docs/adr/*.md` into the repo's ADR folder, then run
   `./scripts/finalize-adrs.sh` (dry-run) and `--apply` from the repo root. It finds the next free
   ADR number, renames the three files, rewrites their `ADR-NNN` id, and fills the Registry/Parcel
   cross-reference automatically (ADR-004 for authorisation is already referenced). Review the
   `git status`/diff and commit the ADR set together.
2. **CI** — copy `.github/workflows/*.yml` into the repo. Confirm the paths (`backend/`,
   `frontend/`) and that the scripts (`lint`, `typecheck`, `build`, `test`) match the repo; the
   frontend `test` step runs only if a `test` script exists, so it is safe during the transition.
3. **Kit fix** — replace the kit's `CLAUDE.md` and `setup-landvault-local.sh` with the versions in
   `kit-fix/`. On next run, the repo's own `CLAUDE.md` is preserved as `CLAUDE.repo.md` and imported,
   so its freeze/operational history is no longer lost.

## Phase 0 "Stabilise delivery" checklist (gate to Phase 1)

- [ ] **Re-observe the baseline:** run `pytest` (+ Ruff, mypy) on the untouched tree; confirm the
      backend suite is actually green *now* (don't inherit "last verified").
- [ ] **Resolve the paused frontend test state:** either finish the Vitest adoption (a governed
      dependency addition — approve per Rule 6) **or** set `"test": "tsc --noEmit && next lint"` as a
      zero-dependency placeholder so `npm test` runs something real. Then the working tree is clean.
- [ ] **CI green** for frontend and backend on a pull request.
- [ ] **Branch/PR checks:** require CI + review before merge; one bounded context per PR.
- [ ] **Local Docker workflow verified** end-to-end.
- [ ] **Keycloak realm** committed as code; secrets moved to a manager; off dev mode (per the
      delivery-platform ADR).
- [ ] **Cloud/staging** chosen via the delivery-platform ADR; **data-residency confirmed** with the
      pilot partner/counsel (the ADR's condition).
- [ ] Clean working tree, repeatable local environment, staging design approved → **proceed to
      Phase 1** (implement the ownership-history ADR before B4 Spatial).

## Notes

- These ADRs record decisions **you approved**; they are drafted to your governance format (Status,
  Context, Decision, Consequences, DoD) and reference the Constitution/Bible they implement.
- The ownership-history ADR keeps the Parcel aggregate's current owner reference unchanged, adds an
  append-only history table owned by Registry, emits domain events, and frames the history as
  *recorded assertions* — never a determination of title. The platform does not decide who owns.
