#!/usr/bin/env bash
# ------------------------------------------------------------------------------
# commit-development-plan.sh
# Commits the final development plan + ADRs + CI into your LOCAL Development-Plan
# clone, on a new branch. Does NOT push (review, then push yourself).
#
# Run it from anywhere inside your local clone (it finds the repo root), with the
# unzipped pack folder as its location, e.g.:
#     cd Development-Plan
#     unzip ~/Downloads/LandVault-Phase0-Governance-Pack.zip -d _phase0
#     ./_phase0/commit-development-plan.sh
#
# Options:
#   --branch <name>   branch to create (default: feat/development-plan-phase0)
#   --no-branch       commit onto the current branch instead of creating one
# ------------------------------------------------------------------------------
set -euo pipefail

SRC="$(cd "$(dirname "$0")" && pwd)"
BRANCH="feat/development-plan-phase0"
MAKE_BRANCH="yes"
while [ $# -gt 0 ]; do
  case "$1" in
    --branch) BRANCH="$2"; shift 2;;
    --no-branch) MAKE_BRANCH="no"; shift;;
    *) echo "Unknown option: $1"; exit 1;;
  esac
done

command -v git >/dev/null 2>&1 || { echo "ERROR: git not installed."; exit 1; }
REPO="$(git rev-parse --show-toplevel 2>/dev/null || true)"
[ -n "$REPO" ] || { echo "ERROR: run this from inside your Development-Plan git clone."; exit 1; }
echo "Repository: $REPO"

# Refuse to run on a dirty tree (commit discipline: one clean change set).
# Ignore UNtracked files (e.g. the unzipped pack) — only modified/staged tracked files block.
if [ -n "$(git -C "$REPO" status --porcelain --untracked-files=no)" ]; then
  echo "ERROR: tracked working-tree changes present. Commit/stash them first."; exit 1
fi

# locate/create the ADR dir
ADR_DIR=""
for d in docs/adr docs/adrs docs/architecture/decisions adr adrs; do
  [ -d "$REPO/$d" ] && ADR_DIR="$d" && break
done
[ -n "$ADR_DIR" ] || { ADR_DIR="docs/adr"; mkdir -p "$REPO/$ADR_DIR"; }
echo "ADR directory: $ADR_DIR"

echo "==> Copying plan, ADRs, and CI into the repo ..."
mkdir -p "$REPO/docs" "$REPO/$ADR_DIR" "$REPO/.github/workflows"
cp "$SRC/docs/DEVELOPMENT_PLAN.md" "$REPO/docs/DEVELOPMENT_PLAN.md"
cp "$SRC/docs/adr/"ADR-*.md "$REPO/$ADR_DIR/"
cp "$SRC/.github/workflows/"*.yml "$REPO/.github/workflows/"
# optional: bring the numbering helper along
mkdir -p "$REPO/scripts"; cp "$SRC/scripts/finalize-adrs.sh" "$REPO/scripts/" 2>/dev/null || true
chmod +x "$REPO/scripts/finalize-adrs.sh" 2>/dev/null || true

echo "==> Assigning ADR numbers + filling cross-references ..."
( cd "$REPO" && ADR_DIR="$ADR_DIR" bash "$SRC/scripts/finalize-adrs.sh" --apply ) || \
  echo "   (finalize-adrs skipped/failed — assign ADR numbers manually before pushing)"

if [ "$MAKE_BRANCH" = "yes" ]; then
  echo "==> Creating branch '$BRANCH' ..."
  git -C "$REPO" checkout -b "$BRANCH"
fi

echo "==> Staging and committing ..."
git -C "$REPO" add "docs/DEVELOPMENT_PLAN.md" "$ADR_DIR/" ".github/workflows/" "scripts/finalize-adrs.sh" 2>/dev/null || \
  git -C "$REPO" add -A
git -C "$REPO" commit -m "docs: final development plan + Phase-0 ADRs and CI

Adds the approved MVP/pilot development plan (docs/DEVELOPMENT_PLAN.md), the
Registry ownership/status-history ADR, the delivery-platform ADR (StoragePort/
R2/WORM, Keycloak, Paystack), the pilot non-functional-targets ADR, and CI
workflows (frontend + backend). Governed by LV-000 v1.7 and docs/bible.

Registry keeps the current owner reference; ownership/status history is an
append-only table owned by Registry, emitted as events, framed as recorded
assertions (never title). RLS ships in the same migration; changes write to the
B1 audit chain; cross-tenant isolation tested. Storage is a provider-agnostic
StoragePort (R2 default) with a declared WORM grade.

Co-Authored-By: Claude <noreply@anthropic.com>"

echo
echo "==> Committed on '$(git -C "$REPO" rev-parse --abbrev-ref HEAD)'."
echo "    Review:  git -C \"$REPO\" show --stat"
echo "    Push:    git -C \"$REPO\" push -u origin $(git -C "$REPO" rev-parse --abbrev-ref HEAD)"
echo "    (Push is left to you — commit discipline.)"
