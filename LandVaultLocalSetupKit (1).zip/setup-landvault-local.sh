#!/usr/bin/env bash
# ------------------------------------------------------------------------------
# LandVault — local setup
# Clones (or updates) the Development-Plan repository and merges the agent bundle
# (CLAUDE.md, AGENTS.md, .claude/, docs/bible/) into it, so the repo is ready to
# use locally with Claude Code or any AGENTS.md-aware agent.
#
# Usage:
#   ./setup-landvault-local.sh                 # clone + merge bundle
#   ./setup-landvault-local.sh --with-deps     # also install frontend/backend deps
#   REPO_URL=<url> ./setup-landvault-local.sh  # override the repo URL (e.g. SSH/fork)
# ------------------------------------------------------------------------------
set -euo pipefail

REPO_URL="${REPO_URL:-https://github.com/chuzcltdchuzc-gif/Development-Plan.git}"
TARGET="${TARGET:-Development-Plan}"
HERE="$(cd "$(dirname "$0")" && pwd)"
WITH_DEPS="no"
[ "${1:-}" = "--with-deps" ] && WITH_DEPS="yes"

command -v git >/dev/null 2>&1 || { echo "ERROR: git is not installed."; exit 1; }

echo "==> Repository: $REPO_URL"
if [ -d "$TARGET/.git" ]; then
  echo "==> Updating existing '$TARGET' ..."
  git -C "$TARGET" pull --ff-only || echo "   (pull skipped — resolve manually if needed)"
else
  echo "==> Cloning into '$TARGET' ..."
  if ! git clone "$REPO_URL" "$TARGET"; then
    echo "ERROR: clone failed. If the repo is private, authenticate first:"
    echo "       gh auth login      (GitHub CLI)   OR use an SSH URL:"
    echo "       REPO_URL=git@github.com:chuzcltdchuzc-gif/Development-Plan.git ./setup-landvault-local.sh"
    exit 1
  fi
fi

echo "==> Merging agent bundle into '$TARGET' ..."
cp "$HERE/CLAUDE.md"  "$TARGET/CLAUDE.md"
cp "$HERE/AGENTS.md"  "$TARGET/AGENTS.md"
mkdir -p "$TARGET/.claude/commands" "$TARGET/.claude/agents" "$TARGET/docs/bible"
cp -R "$HERE/.claude/." "$TARGET/.claude/"
cp -R "$HERE/docs/bible/." "$TARGET/docs/bible/"
echo "   - CLAUDE.md, AGENTS.md, .claude/ (commands, agents, settings), docs/bible/ (LV-000..LV-016 + rules)"

if [ "$WITH_DEPS" = "yes" ]; then
  echo "==> Installing dependencies (best-effort) ..."
  if [ -f "$TARGET/frontend/package.json" ] && command -v npm >/dev/null 2>&1; then
    echo "   - frontend: npm install"; ( cd "$TARGET/frontend" && npm install ) || echo "   (npm install failed — run manually)"
  fi
  if command -v python3 >/dev/null 2>&1; then
    if [ -f "$TARGET/backend/requirements.txt" ]; then
      echo "   - backend: python venv + pip install -r requirements.txt"
      python3 -m venv "$TARGET/backend/.venv" && "$TARGET/backend/.venv/bin/pip" install -q -r "$TARGET/backend/requirements.txt" || echo "   (backend install failed — run manually)"
    elif [ -f "$TARGET/backend/pyproject.toml" ]; then
      echo "   - backend: python venv (pyproject detected; run your installer, e.g. 'pip install -e .' or poetry/uv install)"
      python3 -m venv "$TARGET/backend/.venv" || true
    fi
  fi
fi

cat <<EOF

==> Done. '$TARGET' is ready locally.

Next:
  cd $TARGET
  claude                 # Claude Code auto-loads CLAUDE.md (blueprint + rules)
  # in-session:
  #   Shift+Tab          -> plan mode (read-only planning)
  #   /plan Registry     -> scoped execution plan for a bounded context
  #   /review Registry   -> adversarial second-opinion review vs the blueprint

Tests (as configured in AGENTS.md — adjust if your layout differs):
  cd frontend && npm test
  cd backend  && pytest

Any AGENTS.md-aware agent (Cursor, Aider, Codex, ...) will pick up AGENTS.md automatically.
EOF
