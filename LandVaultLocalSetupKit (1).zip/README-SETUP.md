# LandVault — Agent Setup Bundle

Drop-in configuration that wires **Claude Code** (and any agent that reads `AGENTS.md` — Cursor,
Aider, OpenAI Codex, etc.) to both the **code** (package.json + tests) and the **blueprint**
(the LandVault Constitution, Bible, and build rules), for planning, building, and second-opinion
review.

## What's in here

```
CLAUDE.md                     ← Claude Code auto-loads this; imports AGENTS.md + the blueprint
AGENTS.md                     ← cross-agent instructions (read by many agents automatically)
.claude/
  settings.json               ← pre-authorises test/diff commands; denies destructive ones
  commands/
    plan.md                   ← /plan <context>   — scoped, read-only execution plan
    review.md                 ← /review <target>  — adversarial second-opinion review
  agents/
    planner.md                ← read-only "planner" subagent
    reviewer.md               ← read-only "reviewer" (second opinion) subagent
docs/bible/                   ← the governing library (LV-000 … LV-016 + LandVault-CLAUDE.md)
```

## Install (from the repo root of `Development-Plan`)

1. Copy `CLAUDE.md`, `AGENTS.md`, the `.claude/` folder, and `docs/bible/` into the repo root.
   (If you already keep docs elsewhere, adjust the `@docs/bible/...` paths in `CLAUDE.md`/`AGENTS.md`.)
2. Commit them. They are plain text and safe to share via git.
3. Confirm the command paths in `AGENTS.md` match your repo (`frontend/` for `npm test`,
   `backend/` for `pytest`). Edit if your layout differs.

## Use it

**Claude Code**

```
cd Development-Plan
claude
```

- It auto-loads `CLAUDE.md` (→ `AGENTS.md` + the blueprint).
- Plan first: press `Shift+Tab` for plan mode, or run `/plan Registry`.
- Second opinion: run `/review Registry` (or `/review "uncommitted diff"`).
- Or ask it to use the `planner` / `reviewer` subagents.
- Point at extra files in a prompt with `@path/to/file`; add outside dirs with `--add-dir`.

**Any other agent (Cursor, Aider, Codex, …)**

- Agents that support `AGENTS.md` pick it up automatically from the repo root.
- For others, point the agent at `AGENTS.md` (and `docs/bible/`) as its instructions/rules file —
  e.g. Cursor: reference it from `.cursor/rules`; Aider: pass it via `--read AGENTS.md`.

## Notes

- `settings.json` pre-allows `npm test` / `pytest` / `git diff` so the agent can **observe** the
  suite (the "observe, then complete" rule) and review diffs, while denying `rm -rf`, `git push`,
  and `git commit` so nothing ships without you.
- Everything the agents do is governed by `docs/bible/` — no lower document may contradict a higher.
- The blueprint here is a snapshot; when the Bible/Constitution changes, refresh `docs/bible/`.
