# ------------------------------------------------------------------------------
# LandVault - local setup (Windows PowerShell)
# Clones (or updates) Development-Plan and merges the agent bundle into it.
#
# Usage:
#   ./setup-landvault-local.ps1
#   ./setup-landvault-local.ps1 -WithDeps
#   ./setup-landvault-local.ps1 -RepoUrl "git@github.com:chuzcltdchuzc-gif/Development-Plan.git"
# ------------------------------------------------------------------------------
param(
  [string]$RepoUrl = "https://github.com/chuzcltdchuzc-gif/Development-Plan.git",
  [string]$Target  = "Development-Plan",
  [switch]$WithDeps
)
$ErrorActionPreference = "Stop"
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path

if (-not (Get-Command git -ErrorAction SilentlyContinue)) { Write-Error "git is not installed."; exit 1 }

Write-Host "==> Repository: $RepoUrl"
if (Test-Path "$Target/.git") {
  Write-Host "==> Updating existing '$Target' ..."
  git -C $Target pull --ff-only
} else {
  Write-Host "==> Cloning into '$Target' ..."
  git clone $RepoUrl $Target
  if ($LASTEXITCODE -ne 0) {
    Write-Host "ERROR: clone failed. If the repo is private, run 'gh auth login' or use an SSH -RepoUrl."
    exit 1
  }
}

Write-Host "==> Merging agent bundle into '$Target' ..."
Copy-Item "$Here/CLAUDE.md" "$Target/CLAUDE.md" -Force
Copy-Item "$Here/AGENTS.md" "$Target/AGENTS.md" -Force
New-Item -ItemType Directory -Force -Path "$Target/.claude","$Target/docs/bible" | Out-Null
Copy-Item "$Here/.claude/*" "$Target/.claude/" -Recurse -Force
Copy-Item "$Here/docs/bible/*" "$Target/docs/bible/" -Recurse -Force
Write-Host "   - CLAUDE.md, AGENTS.md, .claude/, docs/bible/ merged."

if ($WithDeps) {
  Write-Host "==> Installing dependencies (best-effort) ..."
  if ((Test-Path "$Target/frontend/package.json") -and (Get-Command npm -ErrorAction SilentlyContinue)) {
    Push-Location "$Target/frontend"; npm install; Pop-Location
  }
  if ((Test-Path "$Target/backend/requirements.txt") -and (Get-Command python -ErrorAction SilentlyContinue)) {
    python -m venv "$Target/backend/.venv"
    & "$Target/backend/.venv/Scripts/pip.exe" install -q -r "$Target/backend/requirements.txt"
  }
}

Write-Host ""
Write-Host "==> Done. '$Target' is ready locally."
Write-Host "    cd $Target ; claude    (Shift+Tab = plan mode; /plan <ctx>; /review <ctx>)"
Write-Host "    Tests: cd frontend; npm test   |   cd backend; pytest"
