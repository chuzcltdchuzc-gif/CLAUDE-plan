# Make Development-Plan ready locally

This kit gets the `Development-Plan` repository onto your machine with the agent bundle
(`CLAUDE.md`, `AGENTS.md`, `.claude/`, `docs/bible/`) already merged in — ready to use with
Claude Code or any `AGENTS.md`-aware agent.

## Quickest path (macOS / Linux)

```bash
unzip LandVault-Local-Setup-Kit.zip
cd landvault-claude-code-setup
chmod +x setup-landvault-local.sh
./setup-landvault-local.sh              # clone + merge the bundle
# or:
./setup-landvault-local.sh --with-deps  # also npm install / pip install
```

## Windows (PowerShell)

```powershell
Expand-Archive LandVault-Local-Setup-Kit.zip
cd landvault-claude-code-setup
./setup-landvault-local.ps1             # add -WithDeps to install dependencies
```

You'll end up with a `Development-Plan/` folder next to the script, containing the real repo
plus the merged bundle. Then:

```bash
cd Development-Plan
claude          # auto-loads CLAUDE.md -> the blueprint + rules
```

In-session: `Shift+Tab` = plan mode · `/plan Registry` = scoped plan · `/review Registry` =
second-opinion review. Tests: `cd frontend && npm test`, `cd backend && pytest`.

## Options & notes

- **Private repo / auth:** if `git clone` fails with 403/permission, authenticate first
  (`gh auth login`) or use SSH: `REPO_URL=git@github.com:chuzcltdchuzc-gif/Development-Plan.git ./setup-landvault-local.sh`.
- **Custom URL / fork:** set `REPO_URL=<url>` (bash) or `-RepoUrl <url>` (PowerShell).
- **Re-run safely:** if `Development-Plan/` already exists, the script does `git pull --ff-only`
  and re-copies the bundle — it won't blow away your work.
- **Layout differs?** The test commands live in `AGENTS.md` (and `.claude/settings.json`). If your
  tests aren't under `frontend/` / `backend/`, edit those paths.
- **Manual alternative (no script):** `git clone <url>` then copy `CLAUDE.md`, `AGENTS.md`,
  `.claude/`, and `docs/bible/` from this kit into the repo root.
- **Keep the blueprint fresh:** `docs/bible/` here is a snapshot of LV-000 v1.7 + the Bible; when
  you amend the Constitution/Bible, refresh that folder.
